//Paul Park
//03-28-2018
//Tic Tac Toe
//Create a tic tac toe game with easy and hard mode. Also has multiplayer 
package tictactoe;//Locating my program in the right package

import javafx.application.Platform;//All of the imports that will be used
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
//The main class
public class TicTacToeController {
	private boolean isFirstPlayer = true;//Used to see whos turn it is
	int turn = 0; //Counts how many turns have passed
	String winner = ""; //Stores who won 
	String gametype = "2-Player"; //The game type the player chose
	static Stage howtoplay = new Stage();//Stage used to create the how to play pop up windows
	static Stage About = new Stage(); //Stage used to create the about pop up windows
	static Stage WinnerStage = new Stage(); //Stage used to create the winner page
	static Stage TiedStage = new Stage(); //Winner used to create the tie pop up window
	//Setting up all the buttons to be used in the program. Gets the ID linked to the fxml file and sets them up as buttons in the controller
	@FXML Button b1; 
	@FXML Button b2; 
	@FXML Button b3; 
	@FXML Button b4; 
	@FXML Button b5; 
	@FXML Button b6; 
	@FXML Button b7; 
	@FXML Button b8; 
	@FXML Button b9; 
	@FXML Button howToButton;
	@FXML Button Aboutbutton; 
	@FXML Button XWin; 
	@FXML Button OWin;
	@FXML Button TieOK; 
	//The plane where the game is played
	@FXML GridPane gameBoard; 
	//When a button is pressed this function will run 
	public void buttonClickHandler(ActionEvent evt) {
		Button clickedButton = (Button) evt.getTarget(); //Gets what button was pressed
		String buttonLabel = clickedButton.getText();//Gets what the text on the button is
		if (gametype.equals("2-Player")) {//If the user chooses 2-player run the 2-player function
			twoPlayer(buttonLabel, clickedButton);//Two player function
		} 
		if (gametype.equals("Easy")) {//If the user chooses easy. Run the easy game
			EasyMode(buttonLabel,clickedButton); //Function used for the easy mode
		}
		if (gametype.equals("Hard")) {//If user chooses hard, run the hard mode
			HardMode(buttonLabel,clickedButton); //Function used for hard mode
		}
	}
	public void twoPlayer(String buttonLabel,Button clickedButton) {//Two player mode
		if ("".equals(buttonLabel) && isFirstPlayer) {//If the button the button clicked by the first player or X run this code
			clickedButton.setText("X");//Set the button text as X to let the players know that the spot is taken
			isFirstPlayer = false;//Changes turn 
			turn++;//Counts turns
			if (turn >= 5) {//If players placed more than five spots and check for winners because this is the lowest amount of turn possible for a winenr
				find3inarow(); //function used to check for winners
			}
		}
		else if ("".equals(buttonLabel) && !isFirstPlayer) {//Same as the X player the only difference is that it places a O instead of an X
			clickedButton.setText("O");
			isFirstPlayer = true;
			turn++;
			if (turn >= 5) {
				find3inarow(); 
			}
		}
	}
	//Easy mode function
	public void EasyMode(String buttonLabel, Button clickedButton) {
		if("".equals(buttonLabel) && isFirstPlayer) {//Allows the first player to choose their spot on the grid when it is their turn
			clickedButton.setText("X");//Puts down the X for first player
			turn++; //counts turns
			isFirstPlayer = false; 
			if (turn >= 5) {
				find3inarow(); //Checks for winenrs after 5 turns
			}
		}
		while (!isFirstPlayer && winner.equals("")) {//Computers turn 
			//The computer will pick a random spot on the grid to place an O.
			String[] btext = {b1.getText(), b2.getText(), b3.getText(), b4.getText(), b5.getText(), b6.getText(), b7.getText(),b8.getText(),b9.getText()};
			Button[] button = {b1,b2,b3,b4,b5,b6,b7,b8,b9};
			int rand = 0; 
			rand = (int)(Math.random()*9);
			if (btext[rand].equals("")) {//Only allows the computer to pick an spot that is empty
				button[rand].setText("O");
				turn++; //counts turns
				isFirstPlayer = true; 
				if (turn >= 5) {
					find3inarow(); //Checks for winners
				}
			}
		}
	}
	//Function used for hard mode
	public void HardMode(String buttonLabel, Button clickedButton) {
		if("".equals(buttonLabel) && isFirstPlayer) {//Allows the first player to place their X in an empty spot
			clickedButton.setText("X");
			turn++; //Counts turns
			isFirstPlayer = false; 
			if (turn >= 5) {
				find3inarow();//Checks for winners 
			}
		}
		while (!isFirstPlayer && winner.equals("")) {//A strategy the computer uses to find the best place to place an O  
			String[] btext = {b1.getText(), b2.getText(), b3.getText(), b4.getText(), b5.getText(), b6.getText(), b7.getText(),b8.getText(),b9.getText()};
			Button[] button = {b1,b2,b3,b4,b5,b6,b7,b8,b9};
			boolean emergency = false; //Used to indicate if the CPU is about to lose or win 
			for (int i= 0; i<=2; i++) {//Checks all rows and columns for possible win conditions
				//The computer adds a certain value to an array depending on whats on a button and where it is. 
				//The total values is used to see where every X and O is and to calculate if the CPU can win or lose 
				int rowvalue = 0; //Used to store whats in a row
				int rowmemory = 0; //Tracks which spot in the row is empty 
				int columnmemory = 0; //Used to store whats in a column
				int columnvalue = 0;//Tracks which spot in the column is empty 
				int diag = 0; //Used to store whats in the diagonal
				int diagmem = 0; //Tracks the empty spots in a diagonal 
				//Checks the top row on the first loop, then second and third. The if statement allows this to happen.
				//If the spot has an X add a 1 to the value
				//If the spot is an O add a 10 to the value
				//If the spot is empty remember the location
				if (btext[i*3].equals("X")) {
					rowvalue = rowvalue + 1; 
				}
				if (btext[i*3 + 1].equals("X")) {
					rowvalue = rowvalue + 1; 
				}
				if (btext[i*3 + 2].equals("X")) {
					rowvalue = rowvalue + 1; 
				}
				if (btext[i*3].equals("O")) {
					rowvalue = rowvalue + 10; 
				}
				if (btext[i*3 + 1].equals("O")) {
					rowvalue = rowvalue + 10; 
				}
				if (btext[i*3 + 2].equals("O")) {
					rowvalue = rowvalue + 10; 
				}
				if (btext[i*3].equals("")) {
					 rowmemory = i*3; 
				}
				if (btext[i*3 + 1].equals("")) {
					rowmemory = i*3 + 1; 
				}
				if (btext[i*3 + 2].equals("")) {
					rowmemory = i*3 + 2;  
				}
				//Checks the first column on the first loop, then second and third. The if statement allows this to happen.
				//If the spot has an X add a 1 to the value
				//If the spot is an O add a 10 to the value
				//If the spot is empty remember the location
				if (btext[i].equals("X")) {
					columnvalue = columnvalue+1; 
				}
				if (btext[i + 3].equals("X")) {
					columnvalue = columnvalue+1; 
				}
				if (btext[i + 6].equals("X")) {
					columnvalue = columnvalue+1; 
				}
				if (btext[i].equals("O")) {
					columnvalue = columnvalue+10; 
				}
				if (btext[i + 3].equals("O")) {
					columnvalue = columnvalue+10; 
				}
				if (btext[i + 6].equals("O")) {
					columnvalue = columnvalue+10; 
				}
				if (btext[i].equals("")) {
					columnmemory = i; 
				}
				if (btext[i + 3].equals("")) {
					columnmemory = i+3; 
				}
				if (btext[i + 6].equals("")) {
					columnmemory = i+6; 
				}
				
				if (rowvalue == 20 && !emergency) {//If there is 2 O in a row the value is 20. The CPU will know they can win so they will place the O in the empty spot of the row
					i = 2; //ends loop
					emergency = true; //Tells the computer it can win 
					button[rowmemory].setText("O");//Places the O 
					isFirstPlayer = true;//Lets the player go
					find3inarow();//Checks to see if anybody won
				}
				else if (columnvalue == 20 && !emergency) {//If there is 2 O in a column the value is 20. The CPU will know they can win and place the O in the empty spot
					i = 2;//Ends loop
					emergency = true;
					button[columnmemory].setText("O");//Places the O 
					isFirstPlayer = true;
					find3inarow();//Checks to see who won
				}
				//Checks the diagonal going from top left to bottom right
				//If the spot has an X add a 1 to the value
				//If the spot is an O add a 10 to the value
				//If the spot is empty remember the location
				if (btext[0].equals("X")) {
					diag = diag + 1; 
				}
				if (btext[4].equals("X")) {
					diag = diag + 1; 
				}
				if (btext[8].equals("X")) {
					diag = diag + 1; 
				}
				if (btext[0].equals("O")) {
					diag = diag + 10; 
				}
				if (btext[4].equals("O")) {
					diag = diag + 10; 
				}
				if (btext[8].equals("O")) {
					diag = diag + 10; 
				}
				if (btext[0].equals("")) {
					diagmem = 0; 
				}
				if (btext[4].equals("")) {
					diagmem = 4; 
				}
				if (btext[8].equals("")) {
					diagmem = 8; 
				}
				if (diag == 20 && !emergency) {//If the diagonal contains two O the value will be 20. The computer knows it can win. It will place the O in the empty spot
					i = 2; //ends loop
					emergency = true; 
					button[diagmem].setText("O");//Places the O
					isFirstPlayer = true;
					find3inarow();//check for winner
				}
				else if (diag == 2 && !emergency) {//If the diagonal contains two X the value will be 2. The computer can lose so it will place an O in the empty spot
					i = 2; 
					emergency = true;
					button[diagmem].setText("O");
					isFirstPlayer = true;
					find3inarow();
				}
				//Checks the diagonal going from top right to bottom left
				//If the spot has an X add a 1 to the value
				//If the spot is an O add a 10 to the value
				//If the spot is empty remember the location
				diag = 0; //Resets the value to store the new diagonal
				if (btext[2].equals("X")) {
					diag = diag + 1; 
				}
				if (btext[4].equals("X")) {
					diag = diag + 1; 
				}
				if (btext[6].equals("X")) {
					diag = diag + 1; 
				}
				if (btext[2].equals("O")) {
					diag = diag + 10; 
				}
				if (btext[4].equals("O")) {
					diag = diag + 10; 
				}
				if (btext[6].equals("O")) {
					diag = diag + 10; 
				}
				if (btext[2].equals("")) {
					diagmem = 2; 
				}
				if (btext[4].equals("")) {
					diagmem = 4; 
				}
				if (btext[6].equals("")) {
					diagmem = 6; 
				}
				if (diag == 20 && !emergency ) {//If the diagonal contains two O the value will be 20. The computer knows it can win. It will place the O in the empty spot
					i = 2; 
					emergency = true; 
					button[diagmem].setText("O");
					isFirstPlayer = true;
					find3inarow();
				}
				else if (diag == 2 && !emergency) {//If the diagonal contains two X the value will be 2. The computer knows it can lose. It will place the O in the empty spot
					i = 2; 
					emergency = true;
					button[diagmem].setText("O");
					isFirstPlayer = true;
					find3inarow();
				}
				else if (rowvalue == 2 && !emergency) {//If the row has 2 X. The value is 2 and the CPU can lose. The CPU will place the O in the empty spot
					i = 2;
					emergency = true;
					button[rowmemory].setText("O");
					isFirstPlayer = true;
					find3inarow();
				}
				else if (columnvalue == 2 && !emergency) {//If the column has 2 X. The value is 2 and the CPU can lose. The CPU will place the O in the empty spot
					i = 2; 
					emergency = true;
					button[columnmemory].setText("O");
					isFirstPlayer = true;
					find3inarow();
				}
			}
			if (emergency) {//Counting turns
				turn++; 
			}
			while (!isFirstPlayer) {//If an emergency did not happen, place a O in a random empty spot
				if (emergency == false) {
					int rand = 0; 
					rand = (int)(Math.random()*9);//Random spot
					if (btext[rand].equals("")) {
						button[rand].setText("O");//Places the O 
						turn++; 
						isFirstPlayer = true; 
						find3inarow();
					}
				}
			}
		}
	}
	public void menuClickedHandler(ActionEvent evt) {//When the menu is clicked, this function is called to handle it
		MenuItem clickedMenu = (MenuItem) evt.getTarget(); //Which menu button was pressed
		String menuLabel = clickedMenu.getText();//What was the text on the button
		if ("2-Player".equals(menuLabel)) {//If the player clicks on 2 player, reset the board and set game type to 2 player which will allow 2 people to play
			ObservableList<Node> buttons = gameBoard.getChildren(); //gets all the buttons on the grid and sets it as empty
			buttons.forEach(btn -> {
				((Button) btn).setText("");
				//Cleans up any indicators of tie or win. Resets the buttons to default style
				btn.getStyleClass().remove("Owinning-button");
				btn.getStyleClass().remove("Xwinning-button");
				btn.getStyleClass().remove("tied-button");
			});
			//Everything is reset so players can play again
			isFirstPlayer = true; 
			turn=0; 
			winner = ""; 
			buttonRevive(); //Turns the buttons back on 
			gametype = "2-Player";
		}
		if ("How to Play".equals(menuLabel)) {//If the How to Play menu is clicked, run the function for this scenario. Opens a pop up window for the How to Play
			openHowToWindow();//Function for pop up window of how to play
		}
		if ("Quit".equals(menuLabel)) {//If the menu Quit clicked, the game board will close
			Platform.exit(); //closes the game board
		}
		if ("About".equals(menuLabel)) {//If the about menu is chosen, open the about pop up window
			About();//Class that will create the pop up window
		}
		if ("Easy".equals(menuLabel)) {//When easy is selected, clean up the board and set the game type as easy so the next game will be in easy mode
			gametype = "Easy";
			ObservableList<Node> buttons = gameBoard.getChildren(); 
			buttons.forEach(btn -> {
				((Button) btn).setText("");
				
				btn.getStyleClass().remove("Owinning-button");
				btn.getStyleClass().remove("Xwinning-button");
				btn.getStyleClass().remove("tied-button");
			});
			isFirstPlayer = true; 
			turn=0; 
			winner = ""; 
			buttonRevive(); 
		}
		if ("Hard".equals(menuLabel)){//When hard is chosen, clean up the baord and set the game type to be Hard so next game played will be in Hard mode
			gametype = "Hard";
			ObservableList<Node> buttons = gameBoard.getChildren(); 
			buttons.forEach(btn -> {
				((Button) btn).setText("");
				
				btn.getStyleClass().remove("Owinning-button");
				btn.getStyleClass().remove("Xwinning-button");
				btn.getStyleClass().remove("tied-button");
			});
			isFirstPlayer = true; 
			turn=0; 
			winner = ""; 
			buttonRevive(); 
		}

	}
	private void openHowToWindow() {//Class for how to play window
		try {
			//This will open the pop up window created. It has the instructions on how to play tic tac toe
			// load the pop up you created
		Pane about = (Pane)FXMLLoader.load(getClass().getResource("howToPlay.fxml"));
				
				// create a new scene
		Scene howToScene = new Scene(about,400,300);

		// add css to the new scene		
		howToScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

		//create new stage to put scene in
				howtoplay.setScene(howToScene);
				howtoplay.setResizable(false);
				howtoplay.showAndWait();
				} catch(Exception e) {
					e.printStackTrace();
				}
		
			}
	private void About() {
		try {
			//This opens up the pop up window which has information about me and the game and developers and etc 
			// load the pop up you created
		Pane howTo = (Pane)FXMLLoader.load(getClass().getResource("About.fxml"));
				
				// create a new scene
		Scene howToScene = new Scene(howTo,400,300);

		// add css to the new scene		
		howToScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

		//create new stage to put scene in
				About.setScene(howToScene);
				About.setResizable(false);
				About.showAndWait();
				} catch(Exception e) {
					e.printStackTrace();
				}
	}
	private void xWin() {//Opens the window when x wins
		try {
			//When X wins, opens up a pop up window I created in FXML which has a congratulation message and other small messages
			// load the pop up you created
		Pane xwin = (Pane)FXMLLoader.load(getClass().getResource("XWinScreen.fxml"));
				
				// create a new scene
		Scene Winner = new Scene(xwin,400,350);

		// add css to the new scene		
		Winner.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

		//create new stage to put scene in
				WinnerStage.setScene(Winner);
				WinnerStage.setResizable(false);
				WinnerStage.showAndWait();
				} catch(Exception e) {
					e.printStackTrace();
				}
	}
	private void OWin() {//Opens the winow when O wins
		//When O wins, opens up a pop up window I created in FXML which has a congratulation message and other small messages
		try {
			// load the pop up you created
		Pane owin = (Pane)FXMLLoader.load(getClass().getResource("OWinScreen.fxml"));
				
				// create a new scene
		Scene Winner = new Scene(owin,400,350);

		// add css to the new scene		
		Winner.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

		//create new stage to put scene in
				WinnerStage.setScene(Winner);
				WinnerStage.setResizable(false);
				WinnerStage.showAndWait();
				} catch(Exception e) {
					e.printStackTrace();
				}
	}
	private void Tied() {//Pop up window for when the game ended in a tie
		try {
			//Opens a pop up window with a text message that says the game was a tie and they should play again
			// load the pop up you created
		Pane tied = (Pane)FXMLLoader.load(getClass().getResource("Tied.fxml"));
				
				// create a new scene
		Scene Tie = new Scene(tied,400,350);

		// add css to the new scene		
		Tie.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

		//create new stage to put scene in
				TiedStage.setScene(Tie);
				TiedStage.setResizable(false);
				TiedStage.showAndWait();
				} catch(Exception e) {
					e.printStackTrace();
				}
	}
	public void closeWindowButtonClickHandler(ActionEvent evt) {
		// make sure the name of the stage is same as in openHowToWindow()
		howtoplay.close();//When the OK button on the pop up window is clicked, the pop up window is closed
	}
	public void closeAbout (ActionEvent evt) {
		About.close(); //When the OK button on the pop up window is clicked, the pop up window is closed
	}
	public void closeXwin (ActionEvent evt) {
		WinnerStage.close(); //When the OK button on the pop up window is clicked, the pop up window is closed
	}
	public void closeOwin (ActionEvent evt) {
		WinnerStage.close();//When the OK button on the pop up window is clicked, the pop up window is closed
	}
	public void tieclose (ActionEvent evt) {
		TiedStage.close();//When the OK button on the pop up window is clicked, the pop up window is closed 
	}

	public void find3inarow() {//Used to figure out who won
		String[] btext = {b1.getText(), b2.getText(), b3.getText(), b4.getText(), b5.getText(), b6.getText(), b7.getText(),b8.getText(),b9.getText()};
		Button[] button = {b1,b2,b3,b4,b5,b6,b7,b8,b9};
		for (int i = 0; i<3;i++) {
			if ("" != btext[i*3] && btext[i*3] == btext[i*3+1] && btext[i*3+1] == btext[i*3+2]) {//checks if any X or O has a 3 in a row
				winner = btext[i*3];//If there is remember who won
				if (winner.equals("X")) {//If its X, highlight the winning row in the X win colors
					xhighlightwinner(button[i*3],button[i*3+1],button[i*3+2]);
				}
				else if (winner.equals("O")) {//If O wins, highlight the winning row in the O win colors
					Ohighlightwinner(button[i*3],button[i*3+1],button[i*3+2]);
				}
				buttonKill(button);//Kills all buttons because game is over
			}
			//checks if there is any 3 in a row for a column
			else if ("" != btext[i] && btext[i]==btext[i+3] && btext[i+3] == btext[i+6]) {
				winner = btext[i];//remember the winner
				if (winner.equals("X")) {//If its X, highlight the winning row in the X win colors
					xhighlightwinner(button[i],button[i + 3],button[i + 6]);
				}
				else if (winner.equals("O")) {//If O wins, highlight the winning row in the O win colors
					Ohighlightwinner(button[i],button[i + 3],button[i + 6]);
				}
				buttonKill(button); //Kills all buttons because game is over
			}
			//Checks if there is any 3 in a row for a diagonal from top left to bottom right 
			else if ("" != btext[0] && btext[0]==btext[4] && btext[4]==btext[8] && i == 2) {
				winner = btext[0];//Remember the winner
				if (winner.equals("X")) {//If its X, highlight the winning row in the X win colors
					xhighlightwinner(button[0],button[4],button[8]);
				}
				else if(winner.equals("O")) {//If O wins, highlight the winning row in the O win colors
					Ohighlightwinner(button[0],button[4],button[8]);
				}
				buttonKill(button);//Kills all buttons because game is over
			}
			//Checks if there is any 3 in a row for top right to bottom left
			else if("" != btext[2] && btext[2] == btext[4] && btext[4] == btext[6] && i ==2) {
				winner = btext[2]; //Remember the winner
				if (winner.equals("X")){//If its X, highlight the winning row in the X win colors
					xhighlightwinner(button[2],button[4],button[6]);
				}
				if (winner.equals("O")) {//If O wins, highlight the winning row in the O win colors
					Ohighlightwinner(button[2],button[4],button[6]);
				}
				buttonKill(button);//Kills all buttons because game is over
			}
			else if(turn == 9 && i == 2 && winner.equals("")) {//If all of the spots are full and no three in a row, the game is tie
				winner = "Tie";//sets winner as tie
				for (int t = 0; t <= 8; t++) {//All button is changed to the tied color
					button[t].getStyleClass().add("tied-button");
				}
				buttonKill(button);//Kills all buttons because game is over
			}
		}
		if (winner.equals("X")) {//If X wins, open the X win pop up window which congratulates the winner
			xWin(); //Function used to create pop up window
		}
		else if (winner.equals("O")) {//If O wins, open the O win pop up window which congratulates the winner
			OWin(); //Function used to create pop up window 
		}
		else if (winner.equals("Tie")) {//If it is a tie, the tie pop up window will open
			Tied();  //Function used to create pop up window
		}
	}
	public void xhighlightwinner(Button first, Button second, Button third) {//Highlights the winning buttons into the winning team colors
		first.getStyleClass().add("Xwinning-button");//Sets the colors of the button from the colors set up in application.css
		second.getStyleClass().add("Xwinning-button");
		third.getStyleClass().add("Xwinning-button");
	}
	public void Ohighlightwinner(Button first, Button second, Button third) {//Highlights the winning buttons into the winning team colors
		first.getStyleClass().add("Owinning-button");//Sets the colors of the button from the colors set up in application.css
		second.getStyleClass().add("Owinning-button");
		third.getStyleClass().add("Owinning-button");
	}

	public void buttonKill(Button[] Button) {//Used to kill all buttons
		for (int i=0; i <= 8; i++) {//Disables all buttons
			Button[i].setDisable(true); 
		}
	}
	public void buttonRevive() {//Used to turn buttons back on 
		Button[] Button = {b1,b2,b3,b4,b5,b6,b7,b8,b9};
		for (int i = 0; i <= 8; i++) {//Turns all of the buttons back on
			Button[i].setDisable(false);
		}
	}
}
