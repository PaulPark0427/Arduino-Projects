//Paul Park
//03-28-2018
//Tic Tac Toe
//Create a tic tac toe game with easy and hard mode. Also has multiplayer 

package tictactoe;//Locating the program in the right package

//All of the imports needed to use FXML and scene builder. 
//Imports used to run the program
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;


public class Main extends Application {//Main class where my functions are ran
	@Override
	public void start(Stage primaryStage) {//opens the fxml 
		try {
			//This class sets up and displays the tic tac toe game board
			BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("TicTacToe.fxml"));//Finds the format from the css
			Scene scene = new Scene(root,280,310);//Size of the game board
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
		} catch(Exception e) {//Catches any errors
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);//Launch screen. Launches the code
	}
}
