#Importing everything I need
import pygame
import sys
import time
import random
import inputbox
pygame.init()
## Screen size
screenSize = (1200,700)
screen = pygame.display.set_mode((screenSize),0)
## Setting up all of the colours that is going to be used
WHITE = (255,255,255)
BLACK = (0,0,0)
RED = (255,0,0)
GREEN = (0,255,0) 
BLUE = (0,0,255)
PURPLE = (125,60,152)
PURPLE2 = (155, 89, 182)
## Setting up the frame rate
clock = pygame.time.Clock ()
FPS = 60
## All of the fonts that is used
fontTitle = pygame.font.SysFont("pristina",75)
titlefont = pygame.font.SysFont("pristina", 100)
leavefont = pygame.font.SysFont ("gabriola",50)
instfont = pygame.font.SysFont ("centaur",50)
optiontitlefont = pygame.font.SysFont ("calisto",125)
optionfont = pygame.font.SysFont ("arial",75)
difficultyfont = pygame.font.SysFont ("Pristina",75)
cordfont = pygame.font.SysFont ("arial",20)
turnfont = pygame.font.SysFont ("gabriola",30)
movefont = pygame.font.SysFont ("arial",40)
##This is ued to center texts
screenx = screen.get_width ()/2

#######Storing all of the Pictures that is going to be used#########
battleback = pygame.image.load ("Battleship pic/battleback.jpg")##Default Background
finger = pygame.image.load ("Battleship pic/smallfing.png")
howtoback = pygame.image.load ("Battleship pic/howtoplay.jpg")
dublin = pygame.image.load ("Battleship pic/dublin.jpg")
control = pygame.image.load ("Battleship pic/control.png")
congrats = pygame.image.load ("Battleship pic/Congrats.png")
sinking = pygame.image.load ("Battleship pic/sinking.png")
##Choosable Background##
animeback = pygame.image.load ("Battleship pic/Chitoge.jpg")
cherryroad = pygame.image.load ("Battleship pic/cherry.jpg")
cherrysky = pygame.image.load ("Battleship pic/cherryback.jpg")
weebtree = pygame.image.load ("Battleship pic/weebtree.png")
battle = pygame.image.load ("Battleship pic/battle.png")
darkback = pygame.image.load ("Battleship pic/darkback.png")
singleship = pygame.image.load ("Battleship pic/singleship.png")
##Images for background picking
chitogepick = pygame.image.load ("Battleship pic/Chitogepick.png")
cherryroadpick = pygame.image.load ("Battleship pic/cherrypick.png")
cherryskypick = pygame.image.load ("Battleship pic/cherrybackpick.png")
weebtreepick = pygame.image.load ("Battleship pic/weebtreepick.png")
battlepick = pygame.image.load ("Battleship pic/battlepick.png")
darkbackpick = pygame.image.load ("Battleship pic/darkbackpick.png")
singleshippick = pygame.image.load ("Battleship pic/singleshippick.png")
defaultpick = pygame.image.load ("Battleship pic/battlebackpick.png")
## Variable used for the mainscreen background
image = battleback
def mainscreen(image):#This is the main code. This is where the main screen is made
##Declaring all of the variables that will be used in this function
    down = 0
    up = 0
    choice = 1
    pick = True
    screen.fill (PURPLE)
## Drawing my background and all of my choices 
    screen.blit (image, (0,0,1240,700))
    title = titlefont.render ("Battleship",True,BLUE)
    titlex = screen.get_width()/2 - title.get_width()/2
    screen.blit (title,(titlex,50))
    Play = fontTitle.render ("Play", True,(241, 196, 15))
    playx = screenx - Play.get_width()/2
    instructions = fontTitle.render ("How To Play", True,(241, 196, 15))
    instructionsx = screenx - instructions.get_width()/2
    settings = fontTitle.render ("Settings", True, (241,196,15))
    settingsx = screenx - settings.get_width ()/2
    leave = fontTitle.render ("Exit", True, (241, 196, 15))
    leavex = screenx - leave.get_width()/2
##Drawing the box around my choices to make the text visible in all backgrounds
    pygame.draw.rect (screen,(BLUE),(playx-5,145,Play.get_width()+10,Play.get_height()+10),0)
    pygame.draw.rect (screen,(BLUE),(instructionsx-5,265, instructions.get_width()+10,instructions.get_height()+10),0)
    pygame.draw.rect (screen,(BLUE),(settingsx-5, 385, settings.get_width()+10,settings.get_height()+10),0)
    pygame.draw.rect (screen,(BLUE),(leavex-5,505,leave.get_width()+10,leave.get_height()+10),0)
    pygame.draw.rect (screen,(203, 67, 53),(playx,150,Play.get_width(),Play.get_height()),0)
    pygame.draw.rect (screen,(203, 67, 53),(instructionsx,270, instructions.get_width(),instructions.get_height()),0)
    pygame.draw.rect (screen,(203, 67, 53),(settingsx, 390, settings.get_width(),settings.get_height()),0)
    pygame.draw.rect (screen,(203, 67, 53),(leavex,510,leave.get_width(),leave.get_height()),0)
    screen.blit (Play,(playx,150))
    screen.blit(instructions,(instructionsx, 270))
    screen.blit (settings,(settingsx,390))
    screen.blit (leave,(leavex,510))
    pygame.display.update()
    while pick:##This allows me to pick what I want to do 
        for event in pygame.event.get ():
            if event.type == pygame.QUIT:##Quits the program if I press the x on the running game modul
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:##When a key is being presed
                if event.key == pygame.K_ESCAPE:##Pressing escape sends the player back to the main menu
                    pygame.quit()
                    sys.exit ()
                if event.key == pygame.K_DOWN:##Pressing down allows the player to pick the option below in the main menu
                    down = 1
                if event.key == pygame.K_UP:##Pressing up allows the players to pick the option on top
                    up = 1
                if event.key == pygame.K_SPACE:##Pressing space finalizes the answer
                    choose = True
                    pick = False
                if event.key == pygame.K_RETURN:##Pressing Enter finalizes the choice and picks it
                    choose = True
                    pick = False
                if event.key == pygame.K_BACKSPACE:
                    main = 1
            if event.type == pygame.KEYUP:##When the keys are up I am setting everything back to normal or a reset
                if event.type == pygame.K_UP:
                    up = 0
                if event.key == pygame.K_DOWN:
                    down = 0
                if event.key == pygame.K_SPACE:
                    choose = False
            if up == 1:##Allows me to keep track on what option the player is hovering over
                choice = choice - 1
                up = 0
                if choice <= 0:
                    choice = 4    
            if down == 1:
                choice = choice + 1
                down = 0
                if choice == 5:
                    choice = 1
            ##This displays which option that the user is hovering over
            if choice == 1:##Shows the player they are hovering the First option
                Play = fontTitle.render ("Play", True,(52, 152, 219))
                playx = screen.get_width()/2 - Play.get_width()/2
                screen.blit (Play,(playx,150))
                instructions = fontTitle.render ("How To Play", True,(241, 196, 15))
                instructionsx = screenx - instructions.get_width()/2
                screen.blit(instructions,(instructionsx, 270))
                leave = fontTitle.render ("Exit", True, (241, 196, 15))
                leavex = screenx - leave.get_width()/2
                screen.blit (leave,(leavex,510))
                pygame.display.update()
            if choice ==2:##Shows the player they are hovering the Second option
                Play = fontTitle.render ("Play", True,(241, 196, 15))
                playx = screen.get_width()/2 - Play.get_width()/2
                screen.blit (Play,(playx,150))
                instructions = fontTitle.render ("How To Play", True,(52, 152, 219))
                instructionsx = screenx - instructions.get_width()/2
                screen.blit(instructions,(instructionsx, 270))
                settings = fontTitle.render ("Settings", True, (241,196,15))
                settingsx = screenx - settings.get_width ()/2
                screen.blit (settings,(settingsx,390))
                pygame.display.update()
            if choice == 3:##Shows the player they are hovering the Third option
                leave = fontTitle.render ("Exit", True, (241, 196, 15))
                leavex = screenx - leave.get_width()/2
                screen.blit (leave,(leavex,510))
                instructions = fontTitle.render ("How To Play", True,(241, 196, 15))
                instructionsx = screenx - instructions.get_width()/2
                screen.blit(instructions,(instructionsx, 270))
                settings = fontTitle.render ("Settings", True, (52, 152, 219))
                settingsx = screenx - settings.get_width ()/2
                screen.blit (settings,(settingsx,390))
                pygame.display.update()
            if choice == 4:##Shows the player they are hovering the Fourth option
                settings = fontTitle.render ("Settings", True, (241,196,15))
                settingsx = screenx - settings.get_width ()/2
                screen.blit (settings,(settingsx,390))
                leave = fontTitle.render ("Exit", True, (52,152,219))
                leavex = screenx - leave.get_width()/2
                screen.blit (leave,(leavex,510))
                Play = fontTitle.render ("Play", True,(241, 196, 15))
                playx = screen.get_width()/2 - Play.get_width()/2
                screen.blit (Play,(playx,150))
                pygame.display.update()
    ##Run these functions depending on the choice
    if choose == True and choice ==1:##Option 1 is to play
        play(image)
    if choose == True and choice ==2:##Option 2 is for instructions
        instruction(image)
    if choose == True and choice == 3:##Option 3 is for options
        options(image)
    if choose == True and choice == 4:##Option 4 is to quit the game
        pygame.quit()
        sys.exit()
#####################################################################################
def mainbackpick(image):##This for picking the background
    backgroundpick = True
    backchoice = 1
    left = 0
    right = 0
    while backgroundpick:##This is how the use can pick the background
        for event in pygame.event.get():
            if event.type == pygame.QUIT:##Quits the game when the x is pressed on the game module
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:##Press escaoe to go back to main menu
                    mainscreen(image)
                if event.key == pygame.K_LEFT:##Press left to hover the option on the left
                    left = 1
                if event.key == pygame.K_RIGHT:##Press right to hover the option on the right
                    right = 1
                if event.key == pygame.K_RETURN:##Press enter to pick the option
                    backgroundpick = False
                if event.key == pygame.K_SPACE:##Press space to pick the option 
                    backgroundpick = False
            if event.type == pygame.KEYUP:##When the keys are up, the hovering does not change
                if event.type == pygame.K_LEFT:
                    left = 0
                if event.key == pygame.K_RIGHT:
                    right = 0
            if right == 1:##Allows the player to keep track of which option he is hovering over
                backchoice = backchoice + 1
                right = 0
                if backchoice > 8:
                    backchoice = 1
            if left == 1:
                left = 0
                backchoice = backchoice - 1
                if backchoice < 1:
                    backchoice = 8
        ##Shows what picture the user is hovering over. The background will also match to show
        ##them what it looks like
        if backchoice ==1:##Shows the player he is hovering over the first background
            screen.blit (animeback, (0,0))
            returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            pygame.draw.rect (screen, PURPLE2, (90,40,220,170), 0)
            screen.blit (chitogepick,(100,50))
            screen.blit (cherryroadpick,(350,50))
            screen.blit (weebtreepick,(600,50))
            screen.blit (cherryskypick, (850,50))
            screen.blit (battlepick,(100,250))
            screen.blit (darkbackpick, (350,250))
            screen.blit (singleshippick,(600,250))
            screen.blit (defaultpick,(850,250))
            pygame.display.update()
        if backchoice == 2: ##Shows the player that he is hovering over the second background
            screen.blit (cherryroad, (0,0))
            returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            screen.blit (chitogepick,(100,50))
            pygame.draw.rect (screen,PURPLE2, (340,40,220,170),0)
            screen.blit (cherryroadpick,(350,50))
            screen.blit (weebtreepick,(600,50))
            screen.blit (cherryskypick, (850,50))
            screen.blit (battlepick,(100,250))
            screen.blit (darkbackpick, (350,250))
            screen.blit (singleshippick,(600,250))
            screen.blit (defaultpick,(850,250))
            pygame.display.update()
        if backchoice == 3:##Shows the player that he is hovering over the Third background
            screen.blit (weebtree, (0,0))
            returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            screen.blit (chitogepick,(100,50))
            screen.blit (cherryroadpick,(350,50))
            pygame.draw.rect (screen,PURPLE2, (590,40,220,170),0)
            screen.blit (weebtreepick,(600,50))
            screen.blit (cherryskypick, (850,50))
            screen.blit (battlepick,(100,250))
            screen.blit (darkbackpick, (350,250))
            screen.blit (singleshippick,(600,250))
            screen.blit (defaultpick,(850,250))
            pygame.display.update()
        if backchoice == 4:##Shows the player that he is hovering over the fourth background
            screen.blit (cherrysky, (0,0))
            returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            screen.blit (chitogepick,(100,50))
            screen.blit (cherryroadpick,(350,50))
            screen.blit (weebtreepick,(600,50))
            pygame.draw.rect (screen,PURPLE2, (840,40,220,170),0)
            screen.blit (cherryskypick, (850,50))
            screen.blit (battlepick,(100,250))
            screen.blit (darkbackpick, (350,250))
            screen.blit (singleshippick,(600,250))
            screen.blit (defaultpick,(850,250))
            pygame.display.update()
        if backchoice == 5:##Shows the player that he is hovering over the fifth background
            screen.blit (battle, (0,0))
            returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            screen.blit (chitogepick,(100,50))
            screen.blit (cherryroadpick,(350,50))
            screen.blit (weebtreepick,(600,50))
            screen.blit (cherryskypick, (850,50))
            pygame.draw.rect (screen,PURPLE2,(90,240,220,170),0)
            screen.blit (battlepick,(100,250))
            screen.blit (darkbackpick, (350,250))
            screen.blit (singleshippick,(600,250))
            screen.blit (defaultpick,(850,250))
            pygame.display.update()
        if backchoice == 6:##Shows the player that he is hovering over the sixth background
            screen.blit (darkback, (0,0))
            returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            screen.blit (chitogepick,(100,50))
            screen.blit (cherryroadpick,(350,50))
            screen.blit (weebtreepick,(600,50))
            screen.blit (cherryskypick, (850,50))
            screen.blit (battlepick,(100,250))
            pygame.draw.rect (screen,PURPLE2,(340,240,220,170),0)
            screen.blit (darkbackpick, (350,250))
            screen.blit (singleshippick,(600,250))
            screen.blit (defaultpick,(850,250))
            pygame.display.update()
        if backchoice == 7:##Shows the player that he is hovering over the seventh background
            screen.blit (singleship, (0,0))
            returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            screen.blit (chitogepick,(100,50))
            screen.blit (cherryroadpick,(350,50))
            screen.blit (weebtreepick,(600,50))
            screen.blit (cherryskypick, (850,50))
            screen.blit (battlepick,(100,250))
            screen.blit (darkbackpick, (350,250))
            pygame.draw.rect (screen,PURPLE2,(590,240,220,170),0)
            screen.blit (singleshippick,(600,250))
            screen.blit (defaultpick,(850,250))
            pygame.display.update()
        if backchoice == 8:##Shows the player that he is hovering over the eight background
            screen.blit (battleback, (0,0))
            returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            screen.blit (chitogepick,(100,50))
            screen.blit (cherryroadpick,(350,50))
            screen.blit (weebtreepick,(600,50))
            screen.blit (cherryskypick, (850,50))
            screen.blit (battlepick,(100,250))
            screen.blit (darkbackpick, (350,250))
            screen.blit (singleshippick,(600,250))
            pygame.draw.rect (screen,PURPLE2,(840,240,220,170),0)
            screen.blit (defaultpick,(850,250))
            pygame.display.update()
    ##Changes the background to the picture the user has chosen 
    if backchoice == 1:##first image
        image = animeback
        mainscreen(image)
    if backchoice == 2:##Second Image
        image = cherryroad
        mainscreen(image)
    if backchoice == 4:##Fourth image
        image = cherrysky
        mainscreen(image)
    if backchoice == 3:##Third image
        image = weebtree
        mainscreen(image)
    if backchoice == 5:##Fifth image
        image = battle
        mainscreen(image)
    if backchoice == 6:##Sixth image
        image = darkback
        mainscreen(image)
    if backchoice == 7:##Seventh image
        image = singleship
        mainscreen(image)
    if backchoice == 8:##Ninth image
        image = battleback
        mainscreen(image)
######################################################################
def options(image):##Making the options page
    ##Declaring the variables that will be used
    picksetting = True
    option = True
    down = 0
    choice = 1
    up = 0
    while picksetting: ##Making the options page
        screen.blit (image, (0,0))
        Settings = optiontitlefont.render ("Settings", True, RED)
        settingsx = screenx - Settings.get_width ()/2
        screen.blit (Settings, (settingsx,50))
        background = optionfont.render ("Background",True,(244, 208, 63))
        backgroundx = screenx - background.get_width()/2
        screen.blit (background,(backgroundx,200))
        sound = optionfont.render ("Sounds",True,(244, 208, 63))
        soundx = screenx - sound.get_width()/2
        screen.blit (sound,(soundx,300))
        textcolour = optionfont.render ("Text colour",True,(244, 208, 63))
        textcolourx = screenx - textcolour.get_width()/2
        screen.blit (textcolour, (textcolourx,400))
        returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
        returnmainx = screenx*2 - returnmain.get_width()
        returnmainy = screen.get_height() - returnmain.get_height()
        screen.blit (returnmain, (returnmainx,returnmainy))
        pygame.display.update ()
        for event in pygame.event.get():##Allowing the user to pick what option they want
            if event.type == pygame.KEYDOWN:##All of this is the same as before so it is explained in detailed above
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.key == pygame.K_ESCAPE:
                    mainscreen(image)
                if event.key == pygame.K_DOWN:
                    down = 1
                if event.key == pygame.K_UP:
                    up = 1
                if event.key == pygame.K_RETURN:
                    picksetting = False
                if event.key == pygame.K_SPACE:
                    picksetting = False
            if event.type == pygame.KEYUP:
                if event.type == pygame.K_UP:
                    up = 0
                if event.key == pygame.K_DOWN:
                    down = 0
            if down == 1:
                choice = choice + 1
                down = 0
                if choice > 3:
                    choice = 1
            if up == 1:
                up = 0
                choice = choice - 1
                if choice < 1:
                    choice = 3
        ##Displaying what choice the user is hovering over
        if choice == 1:
            background = optionfont.render ("Background",True,(46, 204, 113))
            backgroundx = screenx - background.get_width()/2
            screen.blit (background,(backgroundx,200))
            sound = optionfont.render ("Sounds",True,(244, 208, 63))
            soundx = screenx - sound.get_width()/2
            screen.blit (sound,(soundx,300))
            textcolour = optionfont.render ("Text colour",True,(244, 208, 63))
            textcolourx = screenx - textcolour.get_width()/2
            screen.blit (textcolour, (textcolourx,400))
            pygame.display.update()
        if choice == 2:
            background = optionfont.render ("Background",True,(244, 208, 63))
            backgroundx = screenx - background.get_width()/2
            screen.blit (background,(backgroundx,200))
            sound = optionfont.render ("Sounds",True,(46, 204, 113))
            soundx = screenx - sound.get_width()/2
            screen.blit (sound,(soundx,300))
            textcolour = optionfont.render ("Text colour",True,(244, 208, 63))
            textcolourx = screenx - textcolour.get_width()/2
            screen.blit (textcolour, (textcolourx,400))
            pygame.display.update()
        if choice == 3:
            background = optionfont.render ("Background",True,(244, 208, 63))
            backgroundx = screenx - background.get_width()/2
            screen.blit (background,(backgroundx,200))
            sound = optionfont.render ("Sounds",True,(244, 208, 63))
            soundx = screenx - sound.get_width()/2
            screen.blit (sound,(soundx,300))
            textcolour = optionfont.render ("Text colour",True,(46, 204, 113))
            textcolourx = screenx - textcolour.get_width()/2
            screen.blit (textcolour, (textcolourx,400))
            pygame.display.update()
    while options:
        if choice == 1:
            mainbackpick(image)
        if choice == 2:
            screen.blit (image, (0,0))
            pygame.display.update ()
        if choice == 3:
            screen.blit (image, (0,0))
            pygame.display.update ()
#########################################################################################
def instruction(image):##The instructions page
    ##Declaring all of the variables that will be used
    finger = pygame.image.load ("Battleship pic/smallfing.png")
    screen.fill (GREEN)
    howtoplay = True
    choice = 1
    down = 0
    up = 0
    inst = True
    while howtoplay:##The main section for the instructions. User can pick between single and multiplayer
        singleinst = fontTitle.render ("Instructions for Single Player", True,(93, 173, 226))
        singleinstx = screenx - singleinst.get_width()/2
        screen.blit (singleinst, (singleinstx, 200))
        twoinst = fontTitle.render ("Instruction for Two Players",True,(93, 173, 226))
        twoinstx = screenx - twoinst.get_width()/2
        screen.blit (twoinst, (twoinstx,400))
        returnmain = leavefont.render ("Press esc for mainscreen",True,RED)
        returnmainx = screenx*2 - returnmain.get_width()
        returnmainy = screen.get_height() - returnmain.get_height()
        screen.blit (returnmain, (returnmainx,returnmainy))
        remain = screenx/2 -twoinstx
        pygame.display.update()
        for event in pygame.event.get():##Allowing the user to go up and down for the pick
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    mainscreen(image)
                if event.key == pygame.K_DOWN:
                    down = 1
                if event.key == pygame.K_UP:
                    up = 1
                if event.key == pygame.K_RETURN:
                    howtoplay = False
                if event.key == pygame.K_SPACE:
                    howtoplay = False
            if event.type == pygame.KEYUP:
                if event.type == pygame.K_UP:
                    up = 0
                if event.key == pygame.K_DOWN:
                    down = 0
            if down == 1:
                choice = choice + 1
                down = 0
                if choice > 2:
                    choice = 1
            if up == 1:
                up = 0
                choice = choice - 1
                if choice < 1:
                    choice = 2
        ##Showing what option the user is hovering over
        if choice == 1:
            screen.blit (dublin, (0,0,1240,700))
            singleinst = fontTitle.render ("Instructions for Single Player", True,(93, 173, 226))
            singleinstx = screenx - singleinst.get_width()/2
            screen.blit (singleinst, (singleinstx, 200))
            twoinst = fontTitle.render ("Instruction for Two Players",True,(93, 173, 226))
            twoinstx = screenx - twoinst.get_width()/2
            screen.blit (twoinst, (twoinstx,400))
            returnmain = leavefont.render ("Press esc for mainscreen",True,RED)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            remain = screenx/2 -twoinstx
            screen.blit (finger, (1000,240))
            pygame.display.update()
        if choice == 2:
            screen.blit (dublin, (0,0,1240,700))
            singleinst = fontTitle.render ("Instructions for Single Player", True,(93, 173, 226))
            singleinstx = screenx - singleinst.get_width()/2
            screen.blit (singleinst, (singleinstx, 200))
            twoinst = fontTitle.render ("Instruction for Two Players",True,(93, 173, 226))
            twoinstx = screenx - twoinst.get_width()/2
            screen.blit (twoinst, (twoinstx,400))
            returnmain = leavefont.render ("Press esc for mainscreen",True,RED)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            remain = screenx/2 -twoinstx
            screen.blit (finger, (1000,440))
            pygame.display.update()
    while inst:
        xcor = 0
        y = 0
        reading = True
        if choice == 1:##If the player chooses single player instruction for the single player is shown
            screen.blit (howtoback, (0,0,1240,700))
            f = open('Instructions/Singleinst.txt','r')##Opening the text file that has all of the instructions
            fopen = f.read()
            f.close()
            returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            for event in pygame.event.get():##Lets the user quit
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        mainscreen(image)
            for x in fopen:
###Checks every character in the file and display them one by one
###Changes the characters to ascii to see if thee is an enter
###The program identifies enter because enter in ascci is 10 so it can separate from other characters
                char = ord(x)
                textTitle = instfont.render(x, True, (255,0,0))
                xchange = textTitle.get_width()
                if char == 10:##If enter is found in the text file, start a new line to display text
                    y = y + chary
                    xcor = 0
                elif xcor > 1200 - xchange:##If the text goes off the page, start a new line
                    xcor = 0
                    y = y + chary
                    screen.blit(textTitle,(xcor,y))
                    xcor = xchange
                else:##If everything is fine display the texts
                    textTitle = instfont.render(x, True, (255,0,0))
                    screen.blit(textTitle,(xcor,y))
                    chary = textTitle.get_height()
                    xcor = xcor + xchange
            pygame.display.update ()
            while reading:##This stops the screen from updating again and writing over and over
                for event in pygame.event.get():
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:##If escape is pressed, go to main menu
                            mainscreen (image)
            pygame.display.update ()
        if choice == 2:##The same code as instructions for single but this time shows instructions fo the multiplayer
            f = open('Instructions/twoinst.txt','r')
            fopen = f.read()
            f.close()
            xcor = 0
            y = 0
            reading = True
            screen.blit (howtoback, (0,0,1240,700))
            returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
            returnmainx = screenx*2 - returnmain.get_width()
            returnmainy = screen.get_height() - returnmain.get_height()
            screen.blit (returnmain, (returnmainx,returnmainy))
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        mainscreen(image)
            for x in fopen:
                char = ord(x)
                textTitle = instfont.render(x, True, (255,0,0))
                xchange = textTitle.get_width()
                if char == 10:
                    y = y + chary
                    xcor = 0
                elif xcor > 1200 - xchange:
                    xcor = 0
                    y = y + chary
                    screen.blit(textTitle,(xcor,y))
                    xcor = xchange
                else:
                    textTitle = instfont.render(x, True, (255,0,0))
                    screen.blit(textTitle,(xcor,y))
                    chary = textTitle.get_height()
                    xcor = xcor + xchange
            pygame.display.update ()
            while reading:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            mainscreen (image)
            pygame.display.update ()                
    pygame.display.update ()
def play(image):##The Play function
##Declaring the variables
    pickplay = True
    screen.fill (PURPLE)
    pickmode = 1
    pick = False
    while pickplay:##making the page where the player picks multiplayer or single
        screen.blit (image, (0,0,1200,700))
        title = titlefont.render ("Battleship",True,BLUE)
        titlex = screen.get_width()/2 - title.get_width()/2
        screen.blit (title,(titlex,50))
        single = fontTitle.render ("Single Player", True, RED)
        singlex = screenx - single.get_width()/2
        screen.blit (single,(singlex,200))
        multiplay = fontTitle.render ("2 Player", True, RED)
        multiplayx = screenx - multiplay.get_width()/2
        screen.blit (multiplay,(multiplayx,350))
        returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
        returnmainx = screenx*2 - returnmain.get_width()
        returnmainy = screen.get_height() - returnmain.get_height()
        screen.blit (returnmain, (returnmainx,returnmainy))
        for event in pygame.event.get():##Allows the player to quit to mainmenu 
            if event.type == pygame.QUIT:##Already explained above. Picking between the options
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    mainscreen(image)
                if event.key == pygame.K_DOWN:
                    pickmode = pickmode - 1
                if event.key == pygame.K_UP:
                    pickmode = pickmode + 1
                if event.key == pygame.K_RETURN:
                    pick = True
                if event.key == pygame.K_SPACE:
                    pick = True
            if pickmode > 2:
                pickmode = 1
            if pickmode < 1:
                pickmode = 2
        if pickmode == 1:
            pygame.draw.rect (screen, (RED),(800,225,60,28),0)
            screen.blit (finger,(800,225))
            pygame.display.update()
        if pickmode == 2:
            pygame.draw.rect (screen,(RED),(800,375,60,28),0)
            screen.blit (finger,(800,375))
            pygame.display.update()
        if pickmode == 1 and pick == True:
            singleplayer(image)
        if pickmode == 2 and pick == True:
            multiplayer(image)
        pygame.display.update ()
def singleplayer(image):
    play = True
    up = 0
    down = 0
    difficulty = 1
    picked = False
    while play:
        screen.blit (image,(0,0))
        easy = difficultyfont.render ("Easy",True,RED)
        medium = difficultyfont.render ("Medium",True,RED)
        hard = difficultyfont.render ("Impossible",True,RED)
        easyx = screenx - easy.get_width()/2
        mediumx = screenx - medium.get_width()/2
        hardx = screenx - hard.get_width()/2
        screen.blit (easy,(easyx,150))
        screen.blit (medium,(mediumx,250))
        screen.blit (hard,(hardx,350))
        returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
        returnmainx = screenx*2 - returnmain.get_width()
        returnmainy = screen.get_height() - returnmain.get_height()
        screen.blit (returnmain, (returnmainx,returnmainy))
        for event in pygame.event.get():##Allows the player to quit to mainmenu 
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    mainscreen(image)
                if event.key == pygame.K_UP:
                    up = 1
                if event.key == pygame.K_DOWN:
                    down = 1
                if event.key == pygame.K_SPACE:
                    picked = True
                if event.key == pygame.K_RETURN:
                    picked = True
            if up == 1:
                up = 0
                difficulty = difficulty - 1
                if difficulty == 0:
                    difficulty = 3
            if down == 1:
                down = 0
                difficulty = difficulty + 1
                if difficulty == 4:
                    difficulty = 1
        if difficulty == 1:
            easy = difficultyfont.render ("Easy",True,PURPLE)
            medium = difficultyfont.render ("Medium",True,RED)
            hard = difficultyfont.render ("Impossible",True,RED)
            easyx = screenx - easy.get_width()/2
            mediumx = screenx - medium.get_width()/2
            hardx = screenx - hard.get_width()/2
            screen.blit (easy,(easyx,150))
            screen.blit (medium,(mediumx,250))
            screen.blit (hard,(hardx,350))
        if difficulty == 2:
            easy = difficultyfont.render ("Easy",True,RED)
            medium = difficultyfont.render ("Medium",True,PURPLE)
            hard = difficultyfont.render ("Impossible",True,RED)
            easyx = screenx - easy.get_width()/2
            mediumx = screenx - medium.get_width()/2
            hardx = screenx - hard.get_width()/2
            screen.blit (easy,(easyx,150))
            screen.blit (medium,(mediumx,250))
            screen.blit (hard,(hardx,350))
        if difficulty == 3:
            easy = difficultyfont.render ("Easy",True,RED)
            medium = difficultyfont.render ("Medium",True,RED)
            hard = difficultyfont.render ("Impossible",True,PURPLE)
            easyx = screenx - easy.get_width()/2
            mediumx = screenx - medium.get_width()/2
            hardx = screenx - hard.get_width()/2
            screen.blit (easy,(easyx,150))
            screen.blit (medium,(mediumx,250))
            screen.blit (hard,(hardx,350))
        if difficulty == 1 and picked == True:
            easymode(image)
        if difficulty == 2 and picked == True:
            mediummode(image)
        if difficulty == 3 and picked == True:
            hardmode (image)
        pygame.display.update()
def easymode (image):
    easyplay = True
    playerboatx = []
    playerboaty = []
    boatnumber = 0
    ############## Variables for the cpu boat placements
    cpuarray = []
    cpuboat = []
    go = True
    change = True
    test = True
    positioncheck = True
    arraypos = -1
    cor = 0
    numberval = 0
#######Variables for attacking######
    attackpos = []
    hitcor = []
    cpuattackcor = []
    playerattackcor = []
    playerpoints = 0
    cpupoints = 0
    playerpointsneed = 0
    cpupointsneed = 0 
    while easyplay:
        #####Setting all of the variables that will be used to draw the grid 
        xcor = -25
        xcpu = 685
        y = 105
        ycor = 0
        corx = 1
        cory = 75
        coordinate = True
        drawrect = True
        drawrectcpu = True
        placingboat = True
        displayboat = True
        position = True
        yinarray = 0
        boatnumber = 0
        screen.blit (image,(0,0))
        ##Showing the player that he can leave by typing quit or leave into the input box
        returnmain = leavefont.render ("Type leave or quit to go to mainscreen",True,WHITE)
        returnmainx = screenx*2 - returnmain.get_width()
        returnmainy = screen.get_height() - returnmain.get_height()
        screen.blit (returnmain, (returnmainx,returnmainy))
        pygame.draw.rect (screen,WHITE,(0,100,490,490),0)
        pygame.draw.rect (screen,WHITE,(710,100,490,490),0)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        while drawrect: ##This draws the player's grid
            for x in range (0,16,1):
##This will run 16 times because the grid is 16 by 16
                xcor = xcor + 30 ##The x val will increase by 30 everytime because the box is being draw left to right
                cory = cory + 30 ##The cory is increasing by 30 because the y value of grid is being drawn top to bottom
                pygame.draw.rect (screen,BLUE,(xcor,y,30,30),0)##Drawing the boxes left to right
                pygame.draw.line (screen,WHITE,(5,y),(485,y),1)##Drawing he lines top to bottom from left to right
                pygame.draw.line (screen,WHITE,(xcor,105),(xcor,585),1)##Drawing lines left to right from top to bottom
                if coordinate == True:
                    corx = str(corx)##Converts the variable to int because int cannot be used as text
                    playcor = cordfont.render (corx,True,RED)##Making the text for the x and y cordinates
                    screen.blit  (playcor,(xcor + 8,75))##Printing out the values for the x coordinates
                    screen.blit (playcor,(500,cory))##Printing out the the values for the y coordinates
                    corx = int (corx)##Converts into int inorder to increase by 1 because the x and y coordinate increase by 1
                    corx = corx + 1##Increasing variable value
            if y == 555:##Once the y coordinate or the last row is filled end this while loop
                drawrect = False
            y = y + 30##Allows the next boxes to be drawn a row below
            xcor = -25##Restarts the box from the left
            coordinate = False
        pygame.display.update ()##Update to show the player grid
#######All of the variables that will be used in the cpu grid drawing
        y = 105
        coordinate = True
        corx = 1
        cory = 105
        while drawrectcpu: ##This draws the player's grid
            for x in range (0,16,1):
##Grid is 16 by 16 so will draw each row 16 times
                xcpu = xcpu + 30##The x val will increase by 30 everytime because the box is being draw left to right
                pygame.draw.rect (screen,BLUE,(xcpu,y,30,30),0)##Drawing the boxes left to right
                pygame.draw.line (screen,WHITE,(715,y),(1195,y),1)##Drawing he lines top to bottom from left to right
                pygame.draw.line (screen,WHITE,(xcpu,105),(xcpu,585),1)##Drawing lines left to right from top to bottom
                if coordinate == True:
                    corx = str(corx)##Converts the variable to int because int cannot be used as text
                    playcor = cordfont.render (corx,True,RED)##Making the text for the x and y cordinates
                    screen.blit  (playcor,(xcpu + 8,75))##Printing out the values for the x coordinates
                    screen.blit (playcor,(680,cory + 5))##Printing out the the values for the y coordinates
                    corx = int (corx)##Converts into int inorder to increase by 1 because the x and y coordinate increase by 1
                    corx = corx + 1##Increasing variable value
                    cory = cory + 30##Allows the y coordinate value to match the corresponding boxes
            if y == 555:##Once the y coordinate or the last row is filled end this while loop
                drawrectcpu = False
            y = y + 30##Allows the next boxes to be drawn a row below
            xcpu = 685##Restarts the box from the left
            coordinate = False
        ##Arrays and variables that will be used for the gameplay and to store the coordinates of
        ##boats and attacked coordinates 
        xcheck = []
        ycheck = []
        check = []
        run = 0
        cpudisplay = True
        attack = True
        while placingboat:##Placing the boats
##All of the variables tha will be used for the player to place their boats
            boatx = True
            boaty = True
            boatend = True
            displayboat = True
            good = True
            yval = 0
            if boatnumber == 7: ##Once 7 boats are placed, end the player placements and allow for cpu to place boats
                boatx = False
                boaty = False
                boatend = False
                placingboat = False
            while boatx:##Getting the x coordinate for the boats
                turn = turnfont.render ("Pick the x coordinate of the front of boat",True,RED)##Instructions for player
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)##A purple background for all instructions to pop up
                pygame.draw.rect (screen,GREEN,(screenx - turn.get_width()/2,30,turn.get_width(),turn.get_height()),0)##Drawing the box that outlines the instructions
                screen.blit (turn, (screenx - turn.get_width()/2,30))##Displaying the instructions on the game module
                number = inputbox.ask(screen, "Coordinate")##Getting the x coordinate
                if number == "quit" or number == "leave":##If the inputted values meets the leave criteria then leave to main menu
                    mainscreen(image)##Go to main menu
                numberint = int (number)##Changing the inputted value to an integer
                ##The x coordinate is determined depending on which x coordinate was entered
                if numberint == 1:
                    frontboatx = 5
                    boatx = False
                if numberint == 2:
                    frontboatx = 35
                    boatx = False
                if numberint == 3:
                    frontboatx = 65
                    boatx = False
                if numberint == 4:
                    frontboatx = 95
                    boatx = False
                if numberint == 5:
                    frontboatx = 125
                    boatx = False
                if numberint == 6:
                    frontboatx = 155
                    boatx = False
                if numberint == 7:
                    frontboatx = 185
                    boatx = False
                if numberint == 8:
                    frontboatx = 215
                    boatx = False
                if numberint == 9:
                    frontboatx = 245
                    boatx = False
                if numberint == 10:
                    frontboatx = 275
                    boatx = False
                if numberint == 11:
                    frontboatx = 305
                    boatx = False
                if numberint == 12:
                    frontboatx = 335
                    boatx = False
                if numberint == 13:
                    frontboatx = 365
                    boatx = False
                if numberint == 14:
                    frontboatx = 395
                    boatx = False
                if numberint == 15:
                    frontboatx = 425
                    boatx = False
                if numberint == 16:
                    frontboatx = 455
                    boatx = False
                if numberint > 16:
                        inputwrong = turnfont.render ("Please Enter A Valid Coordinate",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - inputwrong.get_width()/2,30,inputwrong.get_width(),inputwrong.get_height()),0)
                        screen.blit (inputwrong,(screenx - inputwrong.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
            playerboatx.append (frontboatx)##Stores the x coordinate value
            xcheck.append (numberint)
            while boaty:##Getting the y coordinate for the player boats
## The sections commented out as a section is a remainder of when I tried to make sure the boat coordinates don't overlap
## I was unable to get it to work and due to the lack of time I was unable to finish it
## Most of the xcheck and ycheck and conversions later are remainders of my failed attempts
## I was unable to remove it all due to the fear of breaking my code
##                yval = 0
                turn = turnfont.render ("Pick the y coordinate of the front of boat",True,RED)##Instruction for Player
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)##Drawing the background where all of the instructions will pop up
                pygame.draw.rect (screen,GREEN,(screenx - turn.get_width()/2,30,turn.get_width(),turn.get_height()),0)##Draws the box that will outline the instructions
                screen.blit (turn, (screenx - turn.get_width()/2,30))##Displaying the instructions to the game screen
                number = inputbox.ask(screen, "Coordinate")##Getting the y coordinate for player boat
                if number == "quit" or number == "leave":##If the leave/quit criteria is met, the player is sent to mainscreen
                    mainscreen(image)##Goes to mainscreen
                numberint = int (number)##Converts the input to an integer
##                print ycheck
                good = True
##                for y in ycheck:
##                    print "hello"
##                    print yval
##                    if y == numberint:
##                        if xcheck[yval] == (playerboatx[yval]-5)/30 + 1 and run > 0:
##                            print "cant"
##                            good = False
##                            boaty = False
##                            boatend = False
##                            yval = -1
##                    yval = yval + 1
                if good == True:##Gets the y value depending on the y coordinate the player entered
                    ycheck.append (numberint)
                    if numberint == 1:
                        frontboaty = 105
                        boaty = False
                    if numberint == 2:
                        frontboaty = 135
                        boaty = False
                    if numberint == 3:
                        frontboaty = 165
                        boaty = False
                    if numberint == 4:
                        frontboaty = 195
                        boaty = False
                    if numberint == 5:
                        frontboaty = 225
                        boaty = False
                    if numberint == 6:
                        frontboaty = 255
                        boaty = False
                    if numberint == 7:
                        frontboaty = 285
                        boaty = False
                    if numberint == 8:
                        frontboaty = 315
                        boaty = False
                    if numberint == 9:
                        frontboaty = 345
                        boaty = False
                    if numberint == 10:
                        frontboaty = 375
                        boaty = False
                    if numberint == 11:
                        frontboaty = 405
                        boaty = False
                    if numberint == 12:
                        frontboaty = 435
                        boaty = False
                    if numberint == 13:
                        frontboaty = 465
                        boaty = False
                    if numberint == 14:
                        frontboaty = 495
                        boaty = False
                    if numberint == 15:
                        frontboaty = 525
                        boaty = False
                    if numberint == 16:
                        frontboaty = 555
                        boaty = False
                    if numberint > 16 or numberint < 1:
                        inputwrong = turnfont.render ("Please Enter A Valid Coordinate",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - inputwrong.get_width()/2,30,inputwrong.get_width(),inputwrong.get_height()),0)
                        screen.blit (inputwrong,(screenx - inputwrong.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
            playerboaty.append (frontboaty)##Stores the y coordinate of boat 
            while boatend:##This is where the middle and end position of the boat is determined
                for x in playerboatx:##Checks every value in the x coordinate array and sets them as the x coordinate for the boxes
                    boaty = playerboaty[yinarray]##Gets the corresponding y value 
                    yinarray = yinarray + 1##This is how the code knows which y value matches the x value
                    pygame.draw.rect (screen,RED,(x+1,boaty+1,29,29),0)##Drawing the box
                    pygame.display.update ()## Updating the screen
                yinarray = 0
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)##Draws the background where the instructions will be shown
                leftmove = movefont.render ("left: move 2 left",True,RED)##type left for the middle and end to on the left side
                rightmove = movefont.render ("right: move 2 right",True,BLUE)##type right for the middle and end to on the right side
                upmove = movefont.render ("up: move 2 up",True,GREEN)##type up for the middle and end to on the upper side
                downmove = movefont.render ("down: move 2 down",True,WHITE)##type down for the middle and end to on the lower side
                ##Displays the instructions
                screen.blit (leftmove,(50,15))
                screen.blit (rightmove,(300,15))
                screen.blit (upmove, (590,15))
                screen.blit (downmove,(820,15))
                number = inputbox.ask(screen, "Direction")##Gets which direction the player wants the boat to be
                if number == "quit" or number == "leave":##If the leave/quit criteria is met the player goes to mainscreen
                    mainscreen(image)##Sent to mainscreen
                elif number == "left" or number == "Left":##Sets the remaining sides of the boat to the left side]
                    boatmiddlex = frontboatx - 30 ##x coordinate for middle of boat
                    boatendx = frontboatx - 60##x coodinate for end of of boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddlex = (frontboatx -5)/30 
                    checkendx = (frontboatx - 5)/30 - 1
                    fronty = (frontboaty - 105)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendx < 5: ##Checks to see if the boat if it doesn't text will appear saying the boat won't fit
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else: ##If the coordinates work then store the coordinates of the boats which will be used to create the boxes 
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (boatmiddlex)
                        playerboatx.append (boatendx)
                        playerboaty.append (frontboaty)
                        playerboaty.append (frontboaty)
                        xcheck.append (checkmiddlex)
                        xcheck.append (checkendx)
                        ycheck.append (fronty)
                        ycheck.append (fronty)
                        boatnumber = boatnumber + 1 ##Allows the code to know that 1 boat was added
                elif number == "right" or number == "Right":##Sets the remaining sides of the boat to the right side
                    boatmiddlex = frontboatx + 30## x coordinate for the middle of boat 
                    boatendx = frontboatx + 60## x coordinate for the end of boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddlex = (frontboatx -5)/30 + 2
                    checkendx = (frontboatx - 5)/30 + 3
                    fronty = (frontboaty - 105)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendx > 455:##Checks to see if the boat if it doesn't text will appear saying the boat won't fit
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else:
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (boatmiddlex)
                        playerboatx.append (boatendx)
                        playerboaty.append (frontboaty)
                        playerboaty.append (frontboaty)
                        xcheck.append (checkmiddlex)
                        xcheck.append (checkendx)
                        ycheck.append (fronty)
                        ycheck.append (fronty)
                        boatnumber = boatnumber + 1##Allows the code to know that 1 boat was added
                elif number == "up" or number == "Up":##Sets the remaining sides of the boat to the upper side
                    boatmiddley = frontboaty - 30 ##y coordinate for the middle part of the boat
                    boatendy = frontboaty - 60 ##y coordinate for the end part of the boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddley = (frontboaty - 105)/30 
                    checkendy = (frontboaty - 105)/30 - 1
                    fronty = (frontboaty - 105)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendy < 100:##Checks if the y coordinate will fit inside the grid
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else:##If the coordinates work then store the coordinates of the boats which will be used to create the boxes 
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (frontboatx)
                        playerboatx.append (frontboatx)
                        playerboaty.append (boatmiddley)
                        playerboaty.append (boatendy)
                        xcheck.append (frontx)
                        xcheck.append (frontx)
                        ycheck.append (checkmiddley)
                        ycheck.append (checkendy)
                        boatnumber = boatnumber + 1##Allows the code to know that 1 boat was added
                elif number == "down" or number == "Down":##Sets the remaining sides of the boat to the upper side
                    boatmiddley = frontboaty + 30##y coordinate for the middle part of the boat
                    boatendy = frontboaty + 60##y coordinate for the end part of the boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddley = (frontboaty - 105)/30 + 2
                    checkendy = (frontboaty - 105)/30 + 3
                    fronty = (frontboaty - 5)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendy > 555:##Checks if the y coordinate will fit inside the grid
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else:##If the coordinates work then store the coordinates of the boats which will be used to create the boxes 
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (frontboatx)
                        playerboatx.append (frontboatx)
                        playerboaty.append (boatmiddley)
                        playerboaty.append (boatendy)
                        xcheck.append (frontx)
                        xcheck.append (frontx)
                        ycheck.append (checkmiddley)
                        ycheck.append (checkendy)
                        boatnumber = boatnumber + 1##Allows the code to know that 1 boat was added
                else:##If the playe inputs a string that isn't direction then tells the player to follow instructions
                    directwrong = turnfont.render ("Please Enter a Valid Direction",True,RED)
                    pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                    pygame.draw.rect (screen,GREEN,(screenx - directwrong.get_width()/2,30,directwrong.get_width(),directwrong.get_height()),0)
                    screen.blit (directwrong,(screenx - directwrong.get_width ()/2,30))
                    pygame.display.update ()
                    time.sleep (2)
                for x in playerboatx:##Displays the boats the player has placed
                    boaty = playerboaty[yinarray]
                    yinarray = yinarray + 1
                    pygame.draw.rect (screen,RED,(x+1,boaty+1,29,29),0)
                    pygame.display.update ()
                yinarray = 0
        yinarray = 0
        for x in playerboatx:##Displays the boats the player has placed
            boaty = playerboaty[yinarray]
            boatycor = (boaty - 105)/30 + 1##Converting the y coordinate to a y grid coordinate
            boatxcor = (x - 5)/30 + 1##Converting the x coordinate to a x grid coordinate
            boat = (boatxcor,boatycor)##Stores x and y coordinate into a variable which is later then
            ##Added to an array which keeps the corresponding x and y cordinates together
            #print check
            check.append (boat)##Stores the x and y cordinates into an array
            yinarray = yinarray + 1
            pygame.draw.rect (screen,RED,(x+1,boaty+1,29,29),0)##Draws the box for player boat
            pygame.display.update ()
        yinarray = 0
#####################CPU boat placement#########################
        while positioncheck:
            while test:
                ####Variables that will be used
                go = True
                change = True
                arraypos = -1
                numberval = 0
                while go:
                    cpuarray = []
                    clear = True
                    i = 0
                    for i in range (1,7,1): ##The cpu will have 6 boats so the range is from 1 to 7 running 6 times
                        cpux = random.randint (1,16)##Random x coordinate value between 1 and 12
                        cpuy = random.randint (1,16)##Random y coordinate value between 1 and 12
                        cpu = (cpux,cpuy) ##Stores the x and y value together so it is easier to separate them later
##                        print cpuarray
##                        print i
                        cpuarray.append (cpu)##Store the variable into the array
                        for x in cpuarray[:-1]: ##For everyvalue in the array except the last one it will check if
                        ##The new randome coordinate does not overlap. The last value is removed because I stored the value into the array
                        ##If i don't take the last one out, there will always be one overlapping. It will overlap itself . 
                            if x == cpu:##If the coordinate is already used then run the loop again
##                                print "wrong"
##                                print x
                                clear = False
                            elif i == 6 and clear == True: ##If there was no repeats then move on
                                go = False
##                                print x 
##                                print cpuarray
                for x in cpuarray:##Counting how many values are in the array
                        numberval = numberval + 1
                while change:##This is where the middle and end of the boat is determined
                    direction = random.randint(1,4) ##Randomizing the direction the end will point relative to the front
                    arraypos = arraypos + 1 ##Doing one value at a time which will allow all of the values to become random
##                    print cpuboat
##                    print direction
                    if direction == 1: 
                        x = cpuarray[arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x: ##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1##Used to determine if it is using x value or y value
                            if cor ==1 :##This is x value
                                cpuxcor = i + 1 
                            if cor == 2:##This is y 
                                cpuycor = i ##Since the y is unaffected so nothing happens
                                cor = 0
                                cpu = (cpuxcor,cpuycor) ##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                        for i in x:##Splits the array in half, x value and y value. This is for the end part of the boat
                            cor = cor + 1##Used to determine if it is using x value or y value
                            if cor ==1 :
                                cpuxcor = i + 2 ##Since it is to the right, the boat increases by 2 because 1 - 16
                                                ##from left to right. End is 2 away from front
                            if cor == 2:##This is y
                                cpuycor = i##Since the y is unaffected so nothing happens
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                direction = 5 
                                cpuboat.append (cpu) ##Add the values to the array
                    elif direction == 2:##The end will point to the left
                        x = cpuarray[arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x:##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1 ##Used to determine if it is using x value or y value
                            if cor ==1 : ##This is x value
                                cpuxcor = i - 1 ##Since it is to the left, the boat decreases by one because 1 - 16 from left to right
                            if cor == 2: ##This is y 
                                cpuycor = i ##Since the y is unaffected so nothing happens
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                direction = 5
                                cpuboat.append (cpu) ##Add the values to the array
                        for i in x:##Splits the array in half, x value and y value. This is for the end part of the boat
                            cor = cor + 1 ##Used to determine if it is using x value or y value
                            if cor ==1 :##This is x value
                                cpuxcor = i - 2 ##Since it is to the left, the boat decrease by 2 because 1 - 16
                                                ##from left to right. End is 2 away from front
                            if cor == 2: ##This is y
                                cpuycor = i ##Since the y is unaffected so nothing happens
                                cor = 0
                                direction = 5
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                    elif direction == 3: ##The end will point downward
                        x = cpuarray [arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x:##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1   ##Used to determine if it is using x value or y value
                            if cor ==1 : ##This is x value
                                cpuxcor = i  ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ##This is y val
                                cpuycor = i + 1 ##The y val increases by one becaue the coordinate increases as it goes down
                                cor = 0
                                cpu = (cpuxcor,cpuycor) ##store the values of both x and y together to make it easier to use 
                                direction = 5
                                cpuboat.append (cpu)##Add the values to the array
                        for i in x: ## This is for the end part of the boat
                            cor = cor + 1##Used to determine if it is using x value or y value
                            if cor ==1 :##X val
                                cpuxcor = i ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ## Y value
                                cpuycor = i + 2  ##The end is 2 greater than the fron because it is 2 apart
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                    elif direction == 4: ##This is when the boat's end will be higher than the front
                        x = cpuarray [arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x:##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1   ##Used to determine if it is using x value or y value
                            if cor ==1 : ##This is x value
                                cpuxcor = i  ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ##This is y val
                                cpuycor = i - 1     ## The y value decreases by 1 because if the middle is to be up the
                                                    ##The y coordinate is going to be higher because the value increases as it goes down
                                cor = 0
                                cpu = (cpuxcor,cpuycor) ##store the values of both x and y together to make it easier to use 
                                direction = 5
                                cpuboat.append (cpu)##Add the values to the array
                        for i in x:# This is for the end part of the boat
                            cor = cor + 1   ##Used to determine if it is using x value or y value
                            if cor ==1 :    ##X val
                                cpuxcor = i ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ##This is y val 
                                cpuycor = i - 2 ##The y value decreases by 2 because the end is 2 apart from the front
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                    if arraypos == numberval - 1: ##Checks if all of the values have been used. If it has been than it quits the current loop and heads to a new one
                        change = False
                        test = False
                        positioncheck = False
##                        print cpuboat
##                        print "done"
                for x in cpuboat: ##This checks for any overlap in the randomly assigned coordinates
                    overlap = 0 
                    for i in cpuboat:
                        if i == x:
                            overlap = overlap + 1
                        if overlap == 2:
                            test = True
                            positioncheck = True
                            cpuboat = []
                            cpuarray = []
                for x in cpuboat: ##Checks if any of the values in the array are outside of the range given
                    for i in x:
                        if i > 16 or i < 1:
                            test = True
                            positioncheck = True
                            cpuboat = []
                            cpuarray = []
        while cpudisplay: ##This is used to draw the boats of the CPU
                          ##This is used to test if it worked or no
            for x in cpuboat:
                for i in x:
                    cor = cor + 1
                    if cor ==1 :
                        cpuxcor = i 
                    if cor == 2:
                        cpuycor = i 
                        cor = 0
                        #pygame.draw.rect (screen,RED,((cpuxcor*30)+686,cpuycor*30 + 76,29,29),0)
                        pygame.display.update()
                for i in x:
                    cor = cor + 1
                    if cor ==1 :
                        cpuxcor = i
                    if cor == 2:
                        cpuycor = i - 2
                        cor = 0
            cpudisplay = False
        for x in cpuboat: ##Finding out how many points the player has to score to win
            playerpointsneed = playerpointsneed + 1
            #print cpuboat
        for x in check: ##Figuring out how many points the cpu has to get to win 
            #print check
            cpupointsneed = cpupointsneed + 1
        while attack: ##This is where the playe and cpu take turns fighting
            #####Variables that will be used and that needs to be refreshed everytime the
            #####Player and CPU has attacked
            playerattack = True
            cpuattack = True
            hit = False
            allowed = True
            ok = True
##            print playerpointsneed
##            print cpupointsneed
            while playerattack: ##Player's turn to attack
                ok = True
                ##Draws the background background where the instructions appear
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                ##Writing the instruction
                playerturn = turnfont.render ("Pick the x coordinate you wish to attack",True,(RED))
                ##Displaying the box that will surround the instruction
                pygame.draw.rect (screen,GREEN,(screenx - playerturn.get_width()/2,30,playerturn.get_width(),playerturn.get_height()),0)
                ## Displaying the instruction 
                screen.blit (playerturn, (screenx - playerturn.get_width()/2,30))
                ##Getting the attack coordinate for x 
                attackcor = inputbox.ask (screen,"Coordinate")
                if attackcor == "leave" or attackcor == "quit": ##If the input value is leave or quit go to mainscreen
                    mainscreen (image)
                attackx = int (attackcor) ##Converts to int to use in array
                ##Writing the instruction to tell the player to pick what y coordinate to attack
                playerturn = turnfont.render ("Pick the y coordinate you wish to attack",True,(RED))
                ##Draws the background background where the instructions appear
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                ##Displaying the box that will surround the instruction
                pygame.draw.rect (screen,GREEN,(screenx - playerturn.get_width()/2,30,playerturn.get_width(),playerturn.get_height()),0)
                ## Displaying the instruction 
                screen.blit (playerturn, (screenx - playerturn.get_width()/2,30))
                attackcor = inputbox.ask (screen,"Coordinate") ##Getting the y coordinate the player wants to attack
                if attackcor == "leave" or attackcor == "quit": ##If the input value is leave or quit go to mainscreen
                    mainscreen (image)
                attacky = int(attackcor) ##Converts to int to use in array
                attack = (attackx,attacky)
                if attackx > 16 or attackx < 1: ##If the x coordinate chose to attack is out of the grid range,
                    allowed = False             ##Tells the player the coordinate is unavailable and foce them to input a new value
                    corunavailable = turnfont.render ("This Coordinate Does Not Work",True,WHITE)
                    pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                    pygame.draw.rect (screen,GREEN,(screenx - corunavailable.get_width()/2,30,corunavailable.get_width(),corunavailable.get_height()),0)
                    screen.blit (corunavailable,(screenx - corunavailable.get_width ()/2,30))
                    pygame.display.update ()
                    time.sleep (2)
                    ok = False
                elif attacky > 16 or attacky < 1:##If the y coordinate chose to attack is out of the grid range,
                    allowed = False             ##Tells the player the coordinate is unavailable and foce them to input a new value
                    corunavailable = turnfont.render ("This Coordinate Does Not Work",True,WHITE)
                    pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                    pygame.draw.rect (screen,GREEN,(screenx - corunavailable.get_width()/2,30,corunavailable.get_width(),corunavailable.get_height()),0)
                    screen.blit (corunavailable,(screenx - corunavailable.get_width ()/2,30))
                    pygame.display.update ()
                    time.sleep (2)
                    ok = False
                elif attacky <= 16 and attacky >= 1 and attackx <=16 and attackx >= 1: ##If the coordinates chosen are within range then move on 
                    allowed = True
                if allowed == True:
                    for x in playerattackcor: ##Checking to see if the new attacking coordinates have been used already.
                        if x == attack:       ## If the position has been already attacked then force the player to pick new coordinates
                            ok = False
                            corattacked = turnfont.render ("You already attacked this coordinate",True,WHITE)
                            pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                            pygame.draw.rect (screen,GREEN,(screenx - corattacked.get_width()/2,30,corattacked.get_width(),corattacked.get_height()),0)
                            screen.blit (corattacked,(screenx - corattacked.get_width ()/2,30))
                            pygame.display.update ()
                            time.sleep (2)
                if ok == True: ##If everything is fine then attack
                    playerattackcor.append (attack)
                    for x in cpuboat:
                        #print x
                        if x == attack: ##If the attacking coordinate matches CPU boat position draw a red box to indicate a hit
                            hitcor.append (attack)
                            hit = True
                            playerpoints = playerpoints + 1 ##Player gets a point for a hit
                            pygame.draw.rect (screen,RED,((attackx*30) + 686,(attacky*30)+76,29,29),0)
                            pygame.display.update()
                        if hit == False: ##If it is a miss then draw a white box to indicate a miss
                            pygame.draw.rect (screen,WHITE,((attackx*30) + 686,(attacky*30)+76,29,29),0)
                            pygame.display.update()
                    playerattack = False ##After attacking the turn ends
            while cpuattack: ##CPU's turn to attack
                #####Variables that will be used and that needs to be refreshed everytime the
                #####Player and CPU has attacked
                redo = False
                attackplayer = True
                hit = False
                ##Randomly picking the x and y coordinate to attack
                cpuattackx = random.randint (1,16)
                cpuattacky = random.randint (1,16)
                cpucor = (cpuattackx,cpuattacky) ##Store the x and y value together to make it easy to track the pairings
                for x in cpuattackcor: ##If the cpu attacks an already attacked position, redo
                    if x == cpucor:
                        redo = True
                        attackplayer = False
                if redo == True: ##Redoing the x and y coordinate random choosing
                    cpuattackx = random.randint (1,16)
                    cpuattacky = random.randint (1,16)
                if attackplayer == True: ##If there is no overlap then store attacking value into an array
                    cpuattackcor.append (cpucor) ##Store the attacking pos to an arrat
                    for x in check: ##Checks everycoordinate attacked
##                        print x
##                        print cpucor
                        if x == cpucor: ##If the cpu attacked coordinates match the player coordinates draw a black box to indicate a hit
                            hit = True
                            cpupoints = cpupoints + 1 ##Gets a point for hit
                            pygame.draw.rect (screen,BLACK,(cpuattackx*30 - 24,cpuattacky*30 + 76,29,29))
                            pygame.display.update()
                        if hit == False:##If its a miss draw a white box
                            pygame.draw.rect (screen,WHITE,(cpuattackx*30 - 24,cpuattacky*30 + 76,29,29))
                            pygame.display.update ()
                    cpuattack = False ##End CPU Turn
            if playerpoints == playerpointsneed: ##If player gets the points needed to win, Player wins
                playerwin(image)
            if cpupoints == cpupointsneed:##If CPU gets the points needed to win, CPU wins
                cpuwin (image)
                pygame.display.update ()
        pygame.display.update()

def mediummode(image):
    medium = True
    playerboatx = []
    playerboaty = []
    boatnumber = 0
    ############## Variables for the cpu boat placements
    cpuarray = []
    cpuboat = []
    go = True
    change = True
    test = True
    positioncheck = True
    arraypos = -1
    cor = 0
    numberval = 0
#######Variables for attacking######
    attackpos = []
    hitcor = []
    cpuattackcor = []
    playerattackcor = []
    playerpoints = 0
    cpupoints = 0
    playerpointsneed = 0
    cpupointsneed = 0 
    while medium:
        #####Setting all of the variables that will be used to draw the grid 
        xcor = -25
        xcpu = 685
        y = 105
        ycor = 0
        corx = 1
        cory = 75
        coordinate = True
        drawrect = True
        drawrectcpu = True
        placingboat = True
        displayboat = True
        position = True
        yinarray = 0
        boatnumber = 0
        screen.blit (image,(0,0))
        ##Showing the player that he can leave by typing quit or leave into the input box
        returnmain = leavefont.render ("Type leave or quit to go to mainscreen",True,WHITE)
        returnmainx = screenx*2 - returnmain.get_width()
        returnmainy = screen.get_height() - returnmain.get_height()
        screen.blit (returnmain, (returnmainx,returnmainy))
        pygame.draw.rect (screen,WHITE,(0,100,490,490),0)
        pygame.draw.rect (screen,WHITE,(710,100,490,490),0)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        while drawrect: ##This draws the player's grid
            for x in range (0,16,1):
##This will run 16 times because the grid is 16 by 16
                xcor = xcor + 30 ##The x val will increase by 30 everytime because the box is being draw left to right
                cory = cory + 30 ##The cory is increasing by 30 because the y value of grid is being drawn top to bottom
                pygame.draw.rect (screen,BLUE,(xcor,y,30,30),0)##Drawing the boxes left to right
                pygame.draw.line (screen,WHITE,(5,y),(485,y),1)##Drawing he lines top to bottom from left to right
                pygame.draw.line (screen,WHITE,(xcor,105),(xcor,585),1)##Drawing lines left to right from top to bottom
                if coordinate == True:
                    corx = str(corx)##Converts the variable to int because int cannot be used as text
                    playcor = cordfont.render (corx,True,RED)##Making the text for the x and y cordinates
                    screen.blit  (playcor,(xcor + 8,75))##Printing out the values for the x coordinates
                    screen.blit (playcor,(500,cory))##Printing out the the values for the y coordinates
                    corx = int (corx)##Converts into int inorder to increase by 1 because the x and y coordinate increase by 1
                    corx = corx + 1##Increasing variable value
            if y == 555:##Once the y coordinate or the last row is filled end this while loop
                drawrect = False
            y = y + 30##Allows the next boxes to be drawn a row below
            xcor = -25##Restarts the box from the left
            coordinate = False
        pygame.display.update ()##Update to show the player grid
#######All of the variables that will be used in the cpu grid drawing
        y = 105
        coordinate = True
        corx = 1
        cory = 105
        while drawrectcpu: ##This draws the player's grid
            for x in range (0,16,1):
##Grid is 16 by 16 so will draw each row 16 times
                xcpu = xcpu + 30##The x val will increase by 30 everytime because the box is being draw left to right
                pygame.draw.rect (screen,BLUE,(xcpu,y,30,30),0)##Drawing the boxes left to right
                pygame.draw.line (screen,WHITE,(715,y),(1195,y),1)##Drawing he lines top to bottom from left to right
                pygame.draw.line (screen,WHITE,(xcpu,105),(xcpu,585),1)##Drawing lines left to right from top to bottom
                if coordinate == True:
                    corx = str(corx)##Converts the variable to int because int cannot be used as text
                    playcor = cordfont.render (corx,True,RED)##Making the text for the x and y cordinates
                    screen.blit  (playcor,(xcpu + 8,75))##Printing out the values for the x coordinates
                    screen.blit (playcor,(680,cory + 5))##Printing out the the values for the y coordinates
                    corx = int (corx)##Converts into int inorder to increase by 1 because the x and y coordinate increase by 1
                    corx = corx + 1##Increasing variable value
                    cory = cory + 30##Allows the y coordinate value to match the corresponding boxes
            if y == 555:##Once the y coordinate or the last row is filled end this while loop
                drawrectcpu = False
            y = y + 30##Allows the next boxes to be drawn a row below
            xcpu = 685##Restarts the box from the left
            coordinate = False
        ##Arrays and variables that will be used for the gameplay and to store the coordinates of
        ##boats and attacked coordinates 
        xcheck = []
        ycheck = []
        check = []
        run = 0
        cpudisplay = True
        attack = True
        while placingboat:##Placing the boats
##All of the variables tha will be used for the player to place their boats
            boatx = True
            boaty = True
            boatend = True
            displayboat = True
            good = True
            yval = 0
            if boatnumber == 7: ##Once 7 boats are placed, end the player placements and allow for cpu to place boats
                boatx = False
                boaty = False
                boatend = False
                placingboat = False
            while boatx:##Getting the x coordinate for the boats
                turn = turnfont.render ("Pick the x coordinate of the front of boat",True,RED)##Instructions for player
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)##A purple background for all instructions to pop up
                pygame.draw.rect (screen,GREEN,(screenx - turn.get_width()/2,30,turn.get_width(),turn.get_height()),0)##Drawing the box that outlines the instructions
                screen.blit (turn, (screenx - turn.get_width()/2,30))##Displaying the instructions on the game module
                number = inputbox.ask(screen, "Coordinate")##Getting the x coordinate
                if number == "quit" or number == "leave":##If the inputted values meets the leave criteria then leave to main menu
                    mainscreen(image)##Go to main menu
                numberint = int (number)##Changing the inputted value to an integer
                ##The x coordinate is determined depending on which x coordinate was entered
                if numberint == 1:
                    frontboatx = 5
                    boatx = False
                if numberint == 2:
                    frontboatx = 35
                    boatx = False
                if numberint == 3:
                    frontboatx = 65
                    boatx = False
                if numberint == 4:
                    frontboatx = 95
                    boatx = False
                if numberint == 5:
                    frontboatx = 125
                    boatx = False
                if numberint == 6:
                    frontboatx = 155
                    boatx = False
                if numberint == 7:
                    frontboatx = 185
                    boatx = False
                if numberint == 8:
                    frontboatx = 215
                    boatx = False
                if numberint == 9:
                    frontboatx = 245
                    boatx = False
                if numberint == 10:
                    frontboatx = 275
                    boatx = False
                if numberint == 11:
                    frontboatx = 305
                    boatx = False
                if numberint == 12:
                    frontboatx = 335
                    boatx = False
                if numberint == 13:
                    frontboatx = 365
                    boatx = False
                if numberint == 14:
                    frontboatx = 395
                    boatx = False
                if numberint == 15:
                    frontboatx = 425
                    boatx = False
                if numberint == 16:
                    frontboatx = 455
                    boatx = False
                if numberint > 16:
                        inputwrong = turnfont.render ("Please Enter A Valid Coordinate",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - inputwrong.get_width()/2,30,inputwrong.get_width(),inputwrong.get_height()),0)
                        screen.blit (inputwrong,(screenx - inputwrong.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
            playerboatx.append (frontboatx)##Stores the x coordinate value
            xcheck.append (numberint)
            while boaty:##Getting the y coordinate for the player boats
## The sections commented out as a section is a remainder of when I tried to make sure the boat coordinates don't overlap
## I was unable to get it to work and due to the lack of time I was unable to finish it
## Most of the xcheck and ycheck and conversions later are remainders of my failed attempts
## I was unable to remove it all due to the fear of breaking my code
##                yval = 0
                turn = turnfont.render ("Pick the y coordinate of the front of boat",True,RED)##Instruction for Player
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)##Drawing the background where all of the instructions will pop up
                pygame.draw.rect (screen,GREEN,(screenx - turn.get_width()/2,30,turn.get_width(),turn.get_height()),0)##Draws the box that will outline the instructions
                screen.blit (turn, (screenx - turn.get_width()/2,30))##Displaying the instructions to the game screen
                number = inputbox.ask(screen, "Coordinate")##Getting the y coordinate for player boat
                if number == "quit" or number == "leave":##If the leave/quit criteria is met, the player is sent to mainscreen
                    mainscreen(image)##Goes to mainscreen
                numberint = int (number)##Converts the input to an integer
##                print ycheck
                good = True
##                for y in ycheck:
##                    print "hello"
##                    print yval
##                    if y == numberint:
##                        if xcheck[yval] == (playerboatx[yval]-5)/30 + 1 and run > 0:
##                            print "cant"
##                            good = False
##                            boaty = False
##                            boatend = False
##                            yval = -1
##                    yval = yval + 1
                if good == True:##Gets the y value depending on the y coordinate the player entered
                    ycheck.append (numberint)
                    if numberint == 1:
                        frontboaty = 105
                        boaty = False
                    if numberint == 2:
                        frontboaty = 135
                        boaty = False
                    if numberint == 3:
                        frontboaty = 165
                        boaty = False
                    if numberint == 4:
                        frontboaty = 195
                        boaty = False
                    if numberint == 5:
                        frontboaty = 225
                        boaty = False
                    if numberint == 6:
                        frontboaty = 255
                        boaty = False
                    if numberint == 7:
                        frontboaty = 285
                        boaty = False
                    if numberint == 8:
                        frontboaty = 315
                        boaty = False
                    if numberint == 9:
                        frontboaty = 345
                        boaty = False
                    if numberint == 10:
                        frontboaty = 375
                        boaty = False
                    if numberint == 11:
                        frontboaty = 405
                        boaty = False
                    if numberint == 12:
                        frontboaty = 435
                        boaty = False
                    if numberint == 13:
                        frontboaty = 465
                        boaty = False
                    if numberint == 14:
                        frontboaty = 495
                        boaty = False
                    if numberint == 15:
                        frontboaty = 525
                        boaty = False
                    if numberint == 16:
                        frontboaty = 555
                        boaty = False
                    if numberint > 16 or numberint < 1:
                        inputwrong = turnfont.render ("Please Enter A Valid Coordinate",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - inputwrong.get_width()/2,30,inputwrong.get_width(),inputwrong.get_height()),0)
                        screen.blit (inputwrong,(screenx - inputwrong.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
            playerboaty.append (frontboaty)##Stores the y coordinate of boat 
            while boatend:##This is where the middle and end position of the boat is determined
                for x in playerboatx:##Checks every value in the x coordinate array and sets them as the x coordinate for the boxes
                    boaty = playerboaty[yinarray]##Gets the corresponding y value 
                    yinarray = yinarray + 1##This is how the code knows which y value matches the x value
                    pygame.draw.rect (screen,RED,(x+1,boaty+1,29,29),0)##Drawing the box
                    pygame.display.update ()## Updating the screen
                yinarray = 0
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)##Draws the background where the instructions will be shown
                leftmove = movefont.render ("left: move 2 left",True,RED)##type left for the middle and end to on the left side
                rightmove = movefont.render ("right: move 2 right",True,BLUE)##type right for the middle and end to on the right side
                upmove = movefont.render ("up: move 2 up",True,GREEN)##type up for the middle and end to on the upper side
                downmove = movefont.render ("down: move 2 down",True,WHITE)##type down for the middle and end to on the lower side
                ##Displays the instructions
                screen.blit (leftmove,(50,15))
                screen.blit (rightmove,(300,15))
                screen.blit (upmove, (590,15))
                screen.blit (downmove,(820,15))
                number = inputbox.ask(screen, "Direction")##Gets which direction the player wants the boat to be
                if number == "quit" or number == "leave":##If the leave/quit criteria is met the player goes to mainscreen
                    mainscreen(image)##Sent to mainscreen
                elif number == "left" or number == "Left":##Sets the remaining sides of the boat to the left side]
                    boatmiddlex = frontboatx - 30 ##x coordinate for middle of boat
                    boatendx = frontboatx - 60##x coodinate for end of of boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddlex = (frontboatx -5)/30 
                    checkendx = (frontboatx - 5)/30 - 1
                    fronty = (frontboaty - 105)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendx < 5: ##Checks to see if the boat if it doesn't text will appear saying the boat won't fit
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else: ##If the coordinates work then store the coordinates of the boats which will be used to create the boxes 
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (boatmiddlex)
                        playerboatx.append (boatendx)
                        playerboaty.append (frontboaty)
                        playerboaty.append (frontboaty)
                        xcheck.append (checkmiddlex)
                        xcheck.append (checkendx)
                        ycheck.append (fronty)
                        ycheck.append (fronty)
                        boatnumber = boatnumber + 1 ##Allows the code to know that 1 boat was added
                elif number == "right" or number == "Right":##Sets the remaining sides of the boat to the right side
                    boatmiddlex = frontboatx + 30## x coordinate for the middle of boat 
                    boatendx = frontboatx + 60## x coordinate for the end of boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddlex = (frontboatx -5)/30 + 2
                    checkendx = (frontboatx - 5)/30 + 3
                    fronty = (frontboaty - 105)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendx > 455:##Checks to see if the boat if it doesn't text will appear saying the boat won't fit
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else:
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (boatmiddlex)
                        playerboatx.append (boatendx)
                        playerboaty.append (frontboaty)
                        playerboaty.append (frontboaty)
                        xcheck.append (checkmiddlex)
                        xcheck.append (checkendx)
                        ycheck.append (fronty)
                        ycheck.append (fronty)
                        boatnumber = boatnumber + 1##Allows the code to know that 1 boat was added
                elif number == "up" or number == "Up":##Sets the remaining sides of the boat to the upper side
                    boatmiddley = frontboaty - 30 ##y coordinate for the middle part of the boat
                    boatendy = frontboaty - 60 ##y coordinate for the end part of the boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddley = (frontboaty - 105)/30 
                    checkendy = (frontboaty - 105)/30 - 1
                    fronty = (frontboaty - 105)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendy < 100:##Checks if the y coordinate will fit inside the grid
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else:##If the coordinates work then store the coordinates of the boats which will be used to create the boxes 
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (frontboatx)
                        playerboatx.append (frontboatx)
                        playerboaty.append (boatmiddley)
                        playerboaty.append (boatendy)
                        xcheck.append (frontx)
                        xcheck.append (frontx)
                        ycheck.append (checkmiddley)
                        ycheck.append (checkendy)
                        boatnumber = boatnumber + 1##Allows the code to know that 1 boat was added
                elif number == "down" or number == "Down":##Sets the remaining sides of the boat to the upper side
                    boatmiddley = frontboaty + 30##y coordinate for the middle part of the boat
                    boatendy = frontboaty + 60##y coordinate for the end part of the boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddley = (frontboaty - 105)/30 + 2
                    checkendy = (frontboaty - 105)/30 + 3
                    fronty = (frontboaty - 5)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendy > 555:##Checks if the y coordinate will fit inside the grid
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else:##If the coordinates work then store the coordinates of the boats which will be used to create the boxes 
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (frontboatx)
                        playerboatx.append (frontboatx)
                        playerboaty.append (boatmiddley)
                        playerboaty.append (boatendy)
                        xcheck.append (frontx)
                        xcheck.append (frontx)
                        ycheck.append (checkmiddley)
                        ycheck.append (checkendy)
                        boatnumber = boatnumber + 1##Allows the code to know that 1 boat was added
                else:##If the playe inputs a string that isn't direction then tells the player to follow instructions
                    directwrong = turnfont.render ("Please Enter a Valid Direction",True,RED)
                    pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                    pygame.draw.rect (screen,GREEN,(screenx - directwrong.get_width()/2,30,directwrong.get_width(),directwrong.get_height()),0)
                    screen.blit (directwrong,(screenx - directwrong.get_width ()/2,30))
                    pygame.display.update ()
                    time.sleep (2)
                for x in playerboatx:##Displays the boats the player has placed
                    boaty = playerboaty[yinarray]
                    yinarray = yinarray + 1
                    pygame.draw.rect (screen,RED,(x+1,boaty+1,29,29),0)
                    pygame.display.update ()
                yinarray = 0
        yinarray = 0
        for x in playerboatx:##Displays the boats the player has placed
            boaty = playerboaty[yinarray]
            boatycor = (boaty - 105)/30 + 1##Converting the y coordinate to a y grid coordinate
            boatxcor = (x - 5)/30 + 1##Converting the x coordinate to a x grid coordinate
            boat = (boatxcor,boatycor)##Stores x and y coordinate into a variable which is later then
            ##Added to an array which keeps the corresponding x and y cordinates together
            #print check
            check.append (boat)##Stores the x and y cordinates into an array
            yinarray = yinarray + 1
            pygame.draw.rect (screen,RED,(x+1,boaty+1,29,29),0)##Draws the box for player boat
            pygame.display.update ()
        yinarray = 0

        
#####################CPU boat placement#########################
        while positioncheck:
            while test:
                ####Variables that will be used
                go = True
                change = True
                arraypos = -1
                numberval = 0
                while go:
                    cpuarray = []
                    clear = True
                    i = 0
                    for i in range (1,11,1): ##The cpu will have 10 boats so the range is from 1 to 11 running 10 times
                        cpux = random.randint (1,16)##Random x coordinate value between 1 and 12
                        cpuy = random.randint (1,16)##Random y coordinate value between 1 and 12
                        cpu = (cpux,cpuy) ##Stores the x and y value together so it is easier to separate them later
##                        print cpuarray
##                        print i
                        cpuarray.append (cpu)##Store the variable into the array
                        for x in cpuarray[:-1]: ##For everyvalue in the array except the last one it will check if
                        ##The new randome coordinate does not overlap. The last value is removed because I stored the value into the array
                        ##If i don't take the last one out, there will always be one overlapping. It will overlap itself . 
                            if x == cpu:##If the coordinate is already used then run the loop again
##                                print "wrong"
##                                print x
                                clear = False
                            elif i == 6 and clear == True: ##If there was no repeats then move on
                                go = False
##                                print x 
##                                print cpuarray
                for x in cpuarray:##Counting how many values are in the array
                        numberval = numberval + 1
                while change:##This is where the middle and end of the boat is determined
                    direction = random.randint(1,4) ##Randomizing the direction the end will point relative to the front
                    arraypos = arraypos + 1 ##Doing one value at a time which will allow all of the values to become random
##                    print cpuboat
##                    print direction
                    if direction == 1: 
                        x = cpuarray[arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x: ##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1##Used to determine if it is using x value or y value
                            if cor ==1 :##This is x value
                                cpuxcor = i + 1 
                            if cor == 2:##This is y 
                                cpuycor = i ##Since the y is unaffected so nothing happens
                                cor = 0
                                cpu = (cpuxcor,cpuycor) ##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                        for i in x:##Splits the array in half, x value and y value. This is for the end part of the boat
                            cor = cor + 1##Used to determine if it is using x value or y value
                            if cor ==1 :
                                cpuxcor = i + 2 ##Since it is to the right, the boat increases by 2 because 1 - 16
                                                ##from left to right. End is 2 away from front
                            if cor == 2:##This is y
                                cpuycor = i##Since the y is unaffected so nothing happens
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                direction = 5 
                                cpuboat.append (cpu) ##Add the values to the array
                    elif direction == 2:##The end will point to the left
                        x = cpuarray[arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x:##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1 ##Used to determine if it is using x value or y value
                            if cor ==1 : ##This is x value
                                cpuxcor = i - 1 ##Since it is to the left, the boat decreases by one because 1 - 16 from left to right
                            if cor == 2: ##This is y 
                                cpuycor = i ##Since the y is unaffected so nothing happens
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                direction = 5
                                cpuboat.append (cpu) ##Add the values to the array
                        for i in x:##Splits the array in half, x value and y value. This is for the end part of the boat
                            cor = cor + 1 ##Used to determine if it is using x value or y value
                            if cor ==1 :##This is x value
                                cpuxcor = i - 2 ##Since it is to the left, the boat decrease by 2 because 1 - 16
                                                ##from left to right. End is 2 away from front
                            if cor == 2: ##This is y
                                cpuycor = i ##Since the y is unaffected so nothing happens
                                cor = 0
                                direction = 5
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                    elif direction == 3: ##The end will point downward
                        x = cpuarray [arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x:##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1   ##Used to determine if it is using x value or y value
                            if cor ==1 : ##This is x value
                                cpuxcor = i  ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ##This is y val
                                cpuycor = i + 1 ##The y val increases by one becaue the coordinate increases as it goes down
                                cor = 0
                                cpu = (cpuxcor,cpuycor) ##store the values of both x and y together to make it easier to use 
                                direction = 5
                                cpuboat.append (cpu)##Add the values to the array
                        for i in x: ## This is for the end part of the boat
                            cor = cor + 1##Used to determine if it is using x value or y value
                            if cor ==1 :##X val
                                cpuxcor = i ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ## Y value
                                cpuycor = i + 2  ##The end is 2 greater than the fron because it is 2 apart
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                    elif direction == 4: ##This is when the boat's end will be higher than the front
                        x = cpuarray [arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x:##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1   ##Used to determine if it is using x value or y value
                            if cor ==1 : ##This is x value
                                cpuxcor = i  ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ##This is y val
                                cpuycor = i - 1     ## The y value decreases by 1 because if the middle is to be up the
                                                    ##The y coordinate is going to be higher because the value increases as it goes down
                                cor = 0
                                cpu = (cpuxcor,cpuycor) ##store the values of both x and y together to make it easier to use 
                                direction = 5
                                cpuboat.append (cpu)##Add the values to the array
                        for i in x:# This is for the end part of the boat
                            cor = cor + 1   ##Used to determine if it is using x value or y value
                            if cor ==1 :    ##X val
                                cpuxcor = i ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ##This is y val 
                                cpuycor = i - 2 ##The y value decreases by 2 because the end is 2 apart from the front
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                    if arraypos == numberval - 1: ##Checks if all of the values have been used. If it has been than it quits the current loop and heads to a new one
                        change = False
                        test = False
                        positioncheck = False
##                        print cpuboat
##                        print "done"
                for x in cpuboat: ##This checks for any overlap in the randomly assigned coordinates
                    overlap = 0 
                    for i in cpuboat:
                        if i == x:
                            overlap = overlap + 1
                        if overlap == 2:
                            test = True
                            positioncheck = True
                            cpuboat = []
                            cpuarray = []
                for x in cpuboat: ##Checks if any of the values in the array are outside of the range given
                    for i in x:
                        if i > 16 or i < 1:
                            test = True
                            positioncheck = True
                            cpuboat = []
                            cpuarray = []
        while cpudisplay: ##This is used to draw the boats of the CPU
                          ##This is used to test if it worked or no
            for x in cpuboat:
                for i in x:
                    cor = cor + 1
                    if cor ==1 :
                        cpuxcor = i 
                    if cor == 2:
                        cpuycor = i 
                        cor = 0
                        #pygame.draw.rect (screen,RED,((cpuxcor*30)+686,cpuycor*30 + 76,29,29),0)
                        pygame.display.update()
                for i in x:
                    cor = cor + 1
                    if cor ==1 :
                        cpuxcor = i
                    if cor == 2:
                        cpuycor = i - 2
                        cor = 0
            cpudisplay = False
        for x in cpuboat: ##Finding out how many points the player has to score to win
            playerpointsneed = playerpointsneed + 1
            #print cpuboat
        for x in check: ##Figuring out how many points the cpu has to get to win 
            #print check
            cpupointsneed = cpupointsneed + 1
        while attack: ##This is where the playe and cpu take turns fighting
            #####Variables that will be used and that needs to be refreshed everytime the
            #####Player and CPU has attacked
            playerattack = True
            cpuattack = True
            hit = False
            allowed = True
            ok = True
##            print playerpointsneed
##            print cpupointsneed
            while playerattack: ##Player's turn to attack
                ok = True
                ##Draws the background background where the instructions appear
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                ##Writing the instruction
                playerturn = turnfont.render ("Pick the x coordinate you wish to attack",True,(RED))
                ##Displaying the box that will surround the instruction
                pygame.draw.rect (screen,GREEN,(screenx - playerturn.get_width()/2,30,playerturn.get_width(),playerturn.get_height()),0)
                ## Displaying the instruction 
                screen.blit (playerturn, (screenx - playerturn.get_width()/2,30))
                ##Getting the attack coordinate for x 
                attackcor = inputbox.ask (screen,"Coordinate")
                if attackcor == "leave" or attackcor == "quit": ##If the input value is leave or quit go to mainscreen
                    mainscreen (image)
                attackx = int (attackcor) ##Converts to int to use in array
                ##Writing the instruction to tell the player to pick what y coordinate to attack
                playerturn = turnfont.render ("Pick the y coordinate you wish to attack",True,(RED))
                ##Draws the background background where the instructions appear
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                ##Displaying the box that will surround the instruction
                pygame.draw.rect (screen,GREEN,(screenx - playerturn.get_width()/2,30,playerturn.get_width(),playerturn.get_height()),0)
                ## Displaying the instruction 
                screen.blit (playerturn, (screenx - playerturn.get_width()/2,30))
                attackcor = inputbox.ask (screen,"Coordinate") ##Getting the y coordinate the player wants to attack
                if attackcor == "leave" or attackcor == "quit": ##If the input value is leave or quit go to mainscreen
                    mainscreen (image)
                attacky = int(attackcor) ##Converts to int to use in array
                attack = (attackx,attacky)
                if attackx > 16 or attackx < 1: ##If the x coordinate chose to attack is out of the grid range,
                    allowed = False             ##Tells the player the coordinate is unavailable and foce them to input a new value
                    corunavailable = turnfont.render ("This Coordinate Does Not Work",True,WHITE)
                    pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                    pygame.draw.rect (screen,GREEN,(screenx - corunavailable.get_width()/2,30,corunavailable.get_width(),corunavailable.get_height()),0)
                    screen.blit (corunavailable,(screenx - corunavailable.get_width ()/2,30))
                    pygame.display.update ()
                    time.sleep (2)
                    ok = False
                elif attacky > 16 or attacky < 1:##If the y coordinate chose to attack is out of the grid range,
                    allowed = False             ##Tells the player the coordinate is unavailable and foce them to input a new value
                    corunavailable = turnfont.render ("This Coordinate Does Not Work",True,WHITE)
                    pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                    pygame.draw.rect (screen,GREEN,(screenx - corunavailable.get_width()/2,30,corunavailable.get_width(),corunavailable.get_height()),0)
                    screen.blit (corunavailable,(screenx - corunavailable.get_width ()/2,30))
                    pygame.display.update ()
                    time.sleep (2)
                    ok = False
                elif attacky <= 16 and attacky >= 1 and attackx <=16 and attackx >= 1: ##If the coordinates chosen are within range then move on 
                    allowed = True
                if allowed == True:
                    for x in playerattackcor: ##Checking to see if the new attacking coordinates have been used already.
                        if x == attack:       ## If the position has been already attacked then force the player to pick new coordinates
                            ok = False
                            corattacked = turnfont.render ("You already attacked this coordinate",True,WHITE)
                            pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                            pygame.draw.rect (screen,GREEN,(screenx - corattacked.get_width()/2,30,corattacked.get_width(),corattacked.get_height()),0)
                            screen.blit (corattacked,(screenx - corattacked.get_width ()/2,30))
                            pygame.display.update ()
                            time.sleep (2)
                if ok == True: ##If everything is fine then attack
                    playerattackcor.append (attack)
                    for x in cpuboat:
                        #print x
                        if x == attack: ##If the attacking coordinate matches CPU boat position draw a red box to indicate a hit
                            hitcor.append (attack)
                            hit = True
                            playerpoints = playerpoints + 1 ##Player gets a point for a hit
                            pygame.draw.rect (screen,RED,((attackx*30) + 686,(attacky*30)+76,29,29),0)
                            pygame.display.update()
                        if hit == False: ##If it is a miss then draw a white box to indicate a miss
                            pygame.draw.rect (screen,WHITE,((attackx*30) + 686,(attacky*30)+76,29,29),0)
                            pygame.display.update()
                    playerattack = False ##After attacking the turn ends
            while cpuattack: ##CPU's turn to attack
                #####Variables that will be used and that needs to be refreshed everytime the
                #####Player and CPU has attacked
                redo = False
                attackplayer = True
                hit = False
                ##Randomly picking the x and y coordinate to attack
                cpuattackx = random.randint (1,16)
                cpuattacky = random.randint (1,16)
                cpucor = (cpuattackx,cpuattacky) ##Store the x and y value together to make it easy to track the pairings
                for x in cpuattackcor: ##If the cpu attacks an already attacked position, redo
                    if x == cpucor:
                        redo = True
                        attackplayer = False
                if redo == True: ##Redoing the x and y coordinate random choosing
                    cpuattackx = random.randint (1,16)
                    cpuattacky = random.randint (1,16)
                if attackplayer == True: ##If there is no overlap then store attacking value into an array
                    cpuattackcor.append (cpucor) ##Store the attacking pos to an arrat
                    for x in check: ##Checks everycoordinate attacked
##                        print x
##                        print cpucor
                        if x == cpucor: ##If the cpu attacked coordinates match the player coordinates draw a black box to indicate a hit
                            hit = True
                            cpupoints = cpupoints + 1 ##Gets a point for hit
                            pygame.draw.rect (screen,BLACK,(cpuattackx*30 - 24,cpuattacky*30 + 76,29,29))
                            pygame.display.update()
                        if hit == False:##If its a miss draw a white box
                            pygame.draw.rect (screen,WHITE,(cpuattackx*30 - 24,cpuattacky*30 + 76,29,29))
                            pygame.display.update ()
                    cpuattack = False ##End CPU Turn
            if playerpoints == playerpointsneed: ##If player gets the points needed to win, Player wins
                playerwin(image)
            if cpupoints == cpupointsneed:##If CPU gets the points needed to win, CPU wins
                cpuwin (image)
                pygame.display.update ()
        pygame.display.update()

def hardmode(image):
    impossible = True
    playerboatx = []
    playerboaty = []
    boatnumber = 0
    ############## Variables for the cpu boat placements
    cpuarray = []
    cpuboat = []
    go = True
    change = True
    test = True
    positioncheck = True
    arraypos = -1
    cor = 0
    numberval = 0
#######Variables for attacking######
    attackpos = []
    hitcor = []
    cpuattackcor = []
    playerattackcor = []
    playerpoints = 0
    cpupoints = 0
    playerpointsneed = 0
    cpupointsneed = 0 
    while impossible:
        #####Setting all of the variables that will be used to draw the grid 
        xcor = -25
        xcpu = 685
        y = 105
        ycor = 0
        corx = 1
        cory = 75
        coordinate = True
        drawrect = True
        drawrectcpu = True
        placingboat = True
        displayboat = True
        position = True
        yinarray = 0
        boatnumber = 0
        screen.blit (image,(0,0))
        ##Showing the player that he can leave by typing quit or leave into the input box
        returnmain = leavefont.render ("Type leave or quit to go to mainscreen",True,WHITE)
        returnmainx = screenx*2 - returnmain.get_width()
        returnmainy = screen.get_height() - returnmain.get_height()
        screen.blit (returnmain, (returnmainx,returnmainy))
        pygame.draw.rect (screen,WHITE,(0,100,490,490),0)
        pygame.draw.rect (screen,WHITE,(710,100,490,490),0)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        while drawrect: ##This draws the player's grid
            for x in range (0,16,1):
##This will run 16 times because the grid is 16 by 16
                xcor = xcor + 30 ##The x val will increase by 30 everytime because the box is being draw left to right
                cory = cory + 30 ##The cory is increasing by 30 because the y value of grid is being drawn top to bottom
                pygame.draw.rect (screen,BLUE,(xcor,y,30,30),0)##Drawing the boxes left to right
                pygame.draw.line (screen,WHITE,(5,y),(485,y),1)##Drawing he lines top to bottom from left to right
                pygame.draw.line (screen,WHITE,(xcor,105),(xcor,585),1)##Drawing lines left to right from top to bottom
                if coordinate == True:
                    corx = str(corx)##Converts the variable to int because int cannot be used as text
                    playcor = cordfont.render (corx,True,RED)##Making the text for the x and y cordinates
                    screen.blit  (playcor,(xcor + 8,75))##Printing out the values for the x coordinates
                    screen.blit (playcor,(500,cory))##Printing out the the values for the y coordinates
                    corx = int (corx)##Converts into int inorder to increase by 1 because the x and y coordinate increase by 1
                    corx = corx + 1##Increasing variable value
            if y == 555:##Once the y coordinate or the last row is filled end this while loop
                drawrect = False
            y = y + 30##Allows the next boxes to be drawn a row below
            xcor = -25##Restarts the box from the left
            coordinate = False
        pygame.display.update ()##Update to show the player grid
#######All of the variables that will be used in the cpu grid drawing
        y = 105
        coordinate = True
        corx = 1
        cory = 105
        while drawrectcpu: ##This draws the player's grid
            for x in range (0,16,1):
##Grid is 16 by 16 so will draw each row 16 times
                xcpu = xcpu + 30##The x val will increase by 30 everytime because the box is being draw left to right
                pygame.draw.rect (screen,BLUE,(xcpu,y,30,30),0)##Drawing the boxes left to right
                pygame.draw.line (screen,WHITE,(715,y),(1195,y),1)##Drawing he lines top to bottom from left to right
                pygame.draw.line (screen,WHITE,(xcpu,105),(xcpu,585),1)##Drawing lines left to right from top to bottom
                if coordinate == True:
                    corx = str(corx)##Converts the variable to int because int cannot be used as text
                    playcor = cordfont.render (corx,True,RED)##Making the text for the x and y cordinates
                    screen.blit  (playcor,(xcpu + 8,75))##Printing out the values for the x coordinates
                    screen.blit (playcor,(680,cory + 5))##Printing out the the values for the y coordinates
                    corx = int (corx)##Converts into int inorder to increase by 1 because the x and y coordinate increase by 1
                    corx = corx + 1##Increasing variable value
                    cory = cory + 30##Allows the y coordinate value to match the corresponding boxes
            if y == 555:##Once the y coordinate or the last row is filled end this while loop
                drawrectcpu = False
            y = y + 30##Allows the next boxes to be drawn a row below
            xcpu = 685##Restarts the box from the left
            coordinate = False
        ##Arrays and variables that will be used for the gameplay and to store the coordinates of
        ##boats and attacked coordinates 
        xcheck = []
        ycheck = []
        check = []
        run = 0
        cpudisplay = True
        attack = True
        while placingboat:##Placing the boats
##All of the variables tha will be used for the player to place their boats
            boatx = True
            boaty = True
            boatend = True
            displayboat = True
            good = True
            yval = 0
            if boatnumber == 7: ##Once 7 boats are placed, end the player placements and allow for cpu to place boats
                boatx = False
                boaty = False
                boatend = False
                placingboat = False
            while boatx:##Getting the x coordinate for the boats
                turn = turnfont.render ("Pick the x coordinate of the front of boat",True,RED)##Instructions for player
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)##A purple background for all instructions to pop up
                pygame.draw.rect (screen,GREEN,(screenx - turn.get_width()/2,30,turn.get_width(),turn.get_height()),0)##Drawing the box that outlines the instructions
                screen.blit (turn, (screenx - turn.get_width()/2,30))##Displaying the instructions on the game module
                number = inputbox.ask(screen, "Coordinate")##Getting the x coordinate
                if number == "quit" or number == "leave":##If the inputted values meets the leave criteria then leave to main menu
                    mainscreen(image)##Go to main menu
                numberint = int (number)##Changing the inputted value to an integer
                ##The x coordinate is determined depending on which x coordinate was entered
                if numberint == 1:
                    frontboatx = 5
                    boatx = False
                if numberint == 2:
                    frontboatx = 35
                    boatx = False
                if numberint == 3:
                    frontboatx = 65
                    boatx = False
                if numberint == 4:
                    frontboatx = 95
                    boatx = False
                if numberint == 5:
                    frontboatx = 125
                    boatx = False
                if numberint == 6:
                    frontboatx = 155
                    boatx = False
                if numberint == 7:
                    frontboatx = 185
                    boatx = False
                if numberint == 8:
                    frontboatx = 215
                    boatx = False
                if numberint == 9:
                    frontboatx = 245
                    boatx = False
                if numberint == 10:
                    frontboatx = 275
                    boatx = False
                if numberint == 11:
                    frontboatx = 305
                    boatx = False
                if numberint == 12:
                    frontboatx = 335
                    boatx = False
                if numberint == 13:
                    frontboatx = 365
                    boatx = False
                if numberint == 14:
                    frontboatx = 395
                    boatx = False
                if numberint == 15:
                    frontboatx = 425
                    boatx = False
                if numberint == 16:
                    frontboatx = 455
                    boatx = False
                if numberint > 16:
                        inputwrong = turnfont.render ("Please Enter A Valid Coordinate",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - inputwrong.get_width()/2,30,inputwrong.get_width(),inputwrong.get_height()),0)
                        screen.blit (inputwrong,(screenx - inputwrong.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
            playerboatx.append (frontboatx)##Stores the x coordinate value
            xcheck.append (numberint)
            while boaty:##Getting the y coordinate for the player boats
## The sections commented out as a section is a remainder of when I tried to make sure the boat coordinates don't overlap
## I was unable to get it to work and due to the lack of time I was unable to finish it
## Most of the xcheck and ycheck and conversions later are remainders of my failed attempts
## I was unable to remove it all due to the fear of breaking my code
##                yval = 0
                turn = turnfont.render ("Pick the y coordinate of the front of boat",True,RED)##Instruction for Player
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)##Drawing the background where all of the instructions will pop up
                pygame.draw.rect (screen,GREEN,(screenx - turn.get_width()/2,30,turn.get_width(),turn.get_height()),0)##Draws the box that will outline the instructions
                screen.blit (turn, (screenx - turn.get_width()/2,30))##Displaying the instructions to the game screen
                number = inputbox.ask(screen, "Coordinate")##Getting the y coordinate for player boat
                if number == "quit" or number == "leave":##If the leave/quit criteria is met, the player is sent to mainscreen
                    mainscreen(image)##Goes to mainscreen
                numberint = int (number)##Converts the input to an integer
##                print ycheck
                good = True
##                for y in ycheck:
##                    print "hello"
##                    print yval
##                    if y == numberint:
##                        if xcheck[yval] == (playerboatx[yval]-5)/30 + 1 and run > 0:
##                            print "cant"
##                            good = False
##                            boaty = False
##                            boatend = False
##                            yval = -1
##                    yval = yval + 1
                if good == True:##Gets the y value depending on the y coordinate the player entered
                    ycheck.append (numberint)
                    if numberint == 1:
                        frontboaty = 105
                        boaty = False
                    if numberint == 2:
                        frontboaty = 135
                        boaty = False
                    if numberint == 3:
                        frontboaty = 165
                        boaty = False
                    if numberint == 4:
                        frontboaty = 195
                        boaty = False
                    if numberint == 5:
                        frontboaty = 225
                        boaty = False
                    if numberint == 6:
                        frontboaty = 255
                        boaty = False
                    if numberint == 7:
                        frontboaty = 285
                        boaty = False
                    if numberint == 8:
                        frontboaty = 315
                        boaty = False
                    if numberint == 9:
                        frontboaty = 345
                        boaty = False
                    if numberint == 10:
                        frontboaty = 375
                        boaty = False
                    if numberint == 11:
                        frontboaty = 405
                        boaty = False
                    if numberint == 12:
                        frontboaty = 435
                        boaty = False
                    if numberint == 13:
                        frontboaty = 465
                        boaty = False
                    if numberint == 14:
                        frontboaty = 495
                        boaty = False
                    if numberint == 15:
                        frontboaty = 525
                        boaty = False
                    if numberint == 16:
                        frontboaty = 555
                        boaty = False
                    if numberint > 16 or numberint < 1:
                        inputwrong = turnfont.render ("Please Enter A Valid Coordinate",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - inputwrong.get_width()/2,30,inputwrong.get_width(),inputwrong.get_height()),0)
                        screen.blit (inputwrong,(screenx - inputwrong.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
            playerboaty.append (frontboaty)##Stores the y coordinate of boat 
            while boatend:##This is where the middle and end position of the boat is determined
                for x in playerboatx:##Checks every value in the x coordinate array and sets them as the x coordinate for the boxes
                    boaty = playerboaty[yinarray]##Gets the corresponding y value 
                    yinarray = yinarray + 1##This is how the code knows which y value matches the x value
                    pygame.draw.rect (screen,RED,(x+1,boaty+1,29,29),0)##Drawing the box
                    pygame.display.update ()## Updating the screen
                yinarray = 0
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)##Draws the background where the instructions will be shown
                leftmove = movefont.render ("left: move 2 left",True,RED)##type left for the middle and end to on the left side
                rightmove = movefont.render ("right: move 2 right",True,BLUE)##type right for the middle and end to on the right side
                upmove = movefont.render ("up: move 2 up",True,GREEN)##type up for the middle and end to on the upper side
                downmove = movefont.render ("down: move 2 down",True,WHITE)##type down for the middle and end to on the lower side
                ##Displays the instructions
                screen.blit (leftmove,(50,15))
                screen.blit (rightmove,(300,15))
                screen.blit (upmove, (590,15))
                screen.blit (downmove,(820,15))
                number = inputbox.ask(screen, "Direction")##Gets which direction the player wants the boat to be
                if number == "quit" or number == "leave":##If the leave/quit criteria is met the player goes to mainscreen
                    mainscreen(image)##Sent to mainscreen
                elif number == "left" or number == "Left":##Sets the remaining sides of the boat to the left side]
                    boatmiddlex = frontboatx - 30 ##x coordinate for middle of boat
                    boatendx = frontboatx - 60##x coodinate for end of of boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddlex = (frontboatx -5)/30 
                    checkendx = (frontboatx - 5)/30 - 1
                    fronty = (frontboaty - 105)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendx < 5: ##Checks to see if the boat if it doesn't text will appear saying the boat won't fit
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else: ##If the coordinates work then store the coordinates of the boats which will be used to create the boxes 
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (boatmiddlex)
                        playerboatx.append (boatendx)
                        playerboaty.append (frontboaty)
                        playerboaty.append (frontboaty)
                        xcheck.append (checkmiddlex)
                        xcheck.append (checkendx)
                        ycheck.append (fronty)
                        ycheck.append (fronty)
                        boatnumber = boatnumber + 1 ##Allows the code to know that 1 boat was added
                elif number == "right" or number == "Right":##Sets the remaining sides of the boat to the right side
                    boatmiddlex = frontboatx + 30## x coordinate for the middle of boat 
                    boatendx = frontboatx + 60## x coordinate for the end of boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddlex = (frontboatx -5)/30 + 2
                    checkendx = (frontboatx - 5)/30 + 3
                    fronty = (frontboaty - 105)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendx > 455:##Checks to see if the boat if it doesn't text will appear saying the boat won't fit
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else:
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (boatmiddlex)
                        playerboatx.append (boatendx)
                        playerboaty.append (frontboaty)
                        playerboaty.append (frontboaty)
                        xcheck.append (checkmiddlex)
                        xcheck.append (checkendx)
                        ycheck.append (fronty)
                        ycheck.append (fronty)
                        boatnumber = boatnumber + 1##Allows the code to know that 1 boat was added
                elif number == "up" or number == "Up":##Sets the remaining sides of the boat to the upper side
                    boatmiddley = frontboaty - 30 ##y coordinate for the middle part of the boat
                    boatendy = frontboaty - 60 ##y coordinate for the end part of the boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddley = (frontboaty - 105)/30 
                    checkendy = (frontboaty - 105)/30 - 1
                    fronty = (frontboaty - 105)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendy < 100:##Checks if the y coordinate will fit inside the grid
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else:##If the coordinates work then store the coordinates of the boats which will be used to create the boxes 
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (frontboatx)
                        playerboatx.append (frontboatx)
                        playerboaty.append (boatmiddley)
                        playerboaty.append (boatendy)
                        xcheck.append (frontx)
                        xcheck.append (frontx)
                        ycheck.append (checkmiddley)
                        ycheck.append (checkendy)
                        boatnumber = boatnumber + 1##Allows the code to know that 1 boat was added
                elif number == "down" or number == "Down":##Sets the remaining sides of the boat to the upper side
                    boatmiddley = frontboaty + 30##y coordinate for the middle part of the boat
                    boatendy = frontboaty + 60##y coordinate for the end part of the boat
                    ##The next four lines are used to convert the coordinates to the number on chart
                    ##Created for the overlap but is still in case I have time to do it 
                    checkmiddley = (frontboaty - 105)/30 + 2
                    checkendy = (frontboaty - 105)/30 + 3
                    fronty = (frontboaty - 5)/30 + 1
                    frontx = (frontboatx - 5)/30 + 1
                    if boatendy > 555:##Checks if the y coordinate will fit inside the grid
                        notfit = turnfont.render ("The Boat Doesn't Fit Please Pick New Direction",True,RED)
                        pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                        pygame.draw.rect (screen,GREEN,(screenx - notfit.get_width()/2,30,notfit.get_width(),notfit.get_height()),0)
                        screen.blit (notfit,(screenx - notfit.get_width ()/2,30))
                        pygame.display.update ()
                        time.sleep (2)
                    else:##If the coordinates work then store the coordinates of the boats which will be used to create the boxes 
                        boatend = False##Ends the while loop and allows the player to place a new boat
                        ##Storing coordinates that will be used for the game play
                        playerboatx.append (frontboatx)
                        playerboatx.append (frontboatx)
                        playerboaty.append (boatmiddley)
                        playerboaty.append (boatendy)
                        xcheck.append (frontx)
                        xcheck.append (frontx)
                        ycheck.append (checkmiddley)
                        ycheck.append (checkendy)
                        boatnumber = boatnumber + 1##Allows the code to know that 1 boat was added
                else:##If the playe inputs a string that isn't direction then tells the player to follow instructions
                    directwrong = turnfont.render ("Please Enter a Valid Direction",True,RED)
                    pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                    pygame.draw.rect (screen,GREEN,(screenx - directwrong.get_width()/2,30,directwrong.get_width(),directwrong.get_height()),0)
                    screen.blit (directwrong,(screenx - directwrong.get_width ()/2,30))
                    pygame.display.update ()
                    time.sleep (2)
                for x in playerboatx:##Displays the boats the player has placed
                    boaty = playerboaty[yinarray]
                    yinarray = yinarray + 1
                    pygame.draw.rect (screen,RED,(x+1,boaty+1,29,29),0)
                    pygame.display.update ()
                yinarray = 0
        yinarray = 0
        for x in playerboatx:##Displays the boats the player has placed
            boaty = playerboaty[yinarray]
            boatycor = (boaty - 105)/30 + 1##Converting the y coordinate to a y grid coordinate
            boatxcor = (x - 5)/30 + 1##Converting the x coordinate to a x grid coordinate
            boat = (boatxcor,boatycor)##Stores x and y coordinate into a variable which is later then
            ##Added to an array which keeps the corresponding x and y cordinates together
            #print check
            check.append (boat)##Stores the x and y cordinates into an array
            yinarray = yinarray + 1
            pygame.draw.rect (screen,RED,(x+1,boaty+1,29,29),0)##Draws the box for player boat
            pygame.display.update ()
        yinarray = 0

        
#####################CPU boat placement#########################
        while positioncheck:
            while test:
                ####Variables that will be used
                go = True
                change = True
                arraypos = -1
                numberval = 0
                while go:
                    cpuarray = []
                    clear = True
                    i = 0
                    for i in range (1,11,1): ##The cpu will have 10 boats so the range is from 1 to 11 running 10 times
                        cpux = random.randint (1,16)##Random x coordinate value between 1 and 12
                        cpuy = random.randint (1,16)##Random y coordinate value between 1 and 12
                        cpu = (cpux,cpuy) ##Stores the x and y value together so it is easier to separate them later
##                        print cpuarray
##                        print i
                        cpuarray.append (cpu)##Store the variable into the array
                        for x in cpuarray[:-1]: ##For everyvalue in the array except the last one it will check if
                        ##The new randome coordinate does not overlap. The last value is removed because I stored the value into the array
                        ##If i don't take the last one out, there will always be one overlapping. It will overlap itself . 
                            if x == cpu:##If the coordinate is already used then run the loop again
##                                print "wrong"
##                                print x
                                clear = False
                            elif i == 6 and clear == True: ##If there was no repeats then move on
                                go = False
##                                print x 
##                                print cpuarray
                for x in cpuarray:##Counting how many values are in the array
                        numberval = numberval + 1
                while change:##This is where the middle and end of the boat is determined
                    direction = random.randint(1,4) ##Randomizing the direction the end will point relative to the front
                    arraypos = arraypos + 1 ##Doing one value at a time which will allow all of the values to become random
##                    print cpuboat
##                    print direction
                    if direction == 1: 
                        x = cpuarray[arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x: ##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1##Used to determine if it is using x value or y value
                            if cor ==1 :##This is x value
                                cpuxcor = i + 1 
                            if cor == 2:##This is y 
                                cpuycor = i ##Since the y is unaffected so nothing happens
                                cor = 0
                                cpu = (cpuxcor,cpuycor) ##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                        for i in x:##Splits the array in half, x value and y value. This is for the end part of the boat
                            cor = cor + 1##Used to determine if it is using x value or y value
                            if cor ==1 :
                                cpuxcor = i + 2 ##Since it is to the right, the boat increases by 2 because 1 - 16
                                                ##from left to right. End is 2 away from front
                            if cor == 2:##This is y
                                cpuycor = i##Since the y is unaffected so nothing happens
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                direction = 5 
                                cpuboat.append (cpu) ##Add the values to the array
                    elif direction == 2:##The end will point to the left
                        x = cpuarray[arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x:##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1 ##Used to determine if it is using x value or y value
                            if cor ==1 : ##This is x value
                                cpuxcor = i - 1 ##Since it is to the left, the boat decreases by one because 1 - 16 from left to right
                            if cor == 2: ##This is y 
                                cpuycor = i ##Since the y is unaffected so nothing happens
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                direction = 5
                                cpuboat.append (cpu) ##Add the values to the array
                        for i in x:##Splits the array in half, x value and y value. This is for the end part of the boat
                            cor = cor + 1 ##Used to determine if it is using x value or y value
                            if cor ==1 :##This is x value
                                cpuxcor = i - 2 ##Since it is to the left, the boat decrease by 2 because 1 - 16
                                                ##from left to right. End is 2 away from front
                            if cor == 2: ##This is y
                                cpuycor = i ##Since the y is unaffected so nothing happens
                                cor = 0
                                direction = 5
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                    elif direction == 3: ##The end will point downward
                        x = cpuarray [arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x:##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1   ##Used to determine if it is using x value or y value
                            if cor ==1 : ##This is x value
                                cpuxcor = i  ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ##This is y val
                                cpuycor = i + 1 ##The y val increases by one becaue the coordinate increases as it goes down
                                cor = 0
                                cpu = (cpuxcor,cpuycor) ##store the values of both x and y together to make it easier to use 
                                direction = 5
                                cpuboat.append (cpu)##Add the values to the array
                        for i in x: ## This is for the end part of the boat
                            cor = cor + 1##Used to determine if it is using x value or y value
                            if cor ==1 :##X val
                                cpuxcor = i ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ## Y value
                                cpuycor = i + 2  ##The end is 2 greater than the fron because it is 2 apart
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                    elif direction == 4: ##This is when the boat's end will be higher than the front
                        x = cpuarray [arraypos]##Used to figure out which value needs to be changed
                        cpuboat.append (x) ##Stores the new value into an array because this is the front which does not change
                        for i in x:##Splits the array in half, x value and y value. This is for the middle part of the boat
                            cor = cor + 1   ##Used to determine if it is using x value or y value
                            if cor ==1 : ##This is x value
                                cpuxcor = i  ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ##This is y val
                                cpuycor = i - 1     ## The y value decreases by 1 because if the middle is to be up the
                                                    ##The y coordinate is going to be higher because the value increases as it goes down
                                cor = 0
                                cpu = (cpuxcor,cpuycor) ##store the values of both x and y together to make it easier to use 
                                direction = 5
                                cpuboat.append (cpu)##Add the values to the array
                        for i in x:# This is for the end part of the boat
                            cor = cor + 1   ##Used to determine if it is using x value or y value
                            if cor ==1 :    ##X val
                                cpuxcor = i ##Since the coordinate is changing up and down so the x value is unaffected
                            if cor == 2: ##This is y val 
                                cpuycor = i - 2 ##The y value decreases by 2 because the end is 2 apart from the front
                                cor = 0
                                cpu = (cpuxcor,cpuycor)##store the values of both x and y together to make it easier to use 
                                cpuboat.append (cpu) ##Add the values to the array
                    if arraypos == numberval - 1: ##Checks if all of the values have been used. If it has been than it quits the current loop and heads to a new one
                        change = False
                        test = False
                        positioncheck = False
##                        print cpuboat
##                        print "done"
                for x in cpuboat: ##This checks for any overlap in the randomly assigned coordinates
                    overlap = 0 
                    for i in cpuboat:
                        if i == x:
                            overlap = overlap + 1
                        if overlap == 2:
                            test = True
                            positioncheck = True
                            cpuboat = []
                            cpuarray = []
                for x in cpuboat: ##Checks if any of the values in the array are outside of the range given
                    for i in x:
                        if i > 16 or i < 1:
                            test = True
                            positioncheck = True
                            cpuboat = []
                            cpuarray = []
        while cpudisplay: ##This is used to draw the boats of the CPU
                          ##This is used to test if it worked or no
            for x in cpuboat:
                for i in x:
                    cor = cor + 1
                    if cor ==1 :
                        cpuxcor = i 
                    if cor == 2:
                        cpuycor = i 
                        cor = 0
                        #pygame.draw.rect (screen,RED,((cpuxcor*30)+686,cpuycor*30 + 76,29,29),0)
                        pygame.display.update()
                for i in x:
                    cor = cor + 1
                    if cor ==1 :
                        cpuxcor = i
                    if cor == 2:
                        cpuycor = i - 2
                        cor = 0
            cpudisplay = False
        for x in cpuboat: ##Finding out how many points the player has to score to win
            playerpointsneed = playerpointsneed + 1
            #print cpuboat
        cpuabsolute = []
        cpuhit = 0
        for x in check: ##Figuring out how many points the cpu has to get to win 
            #print check
            cpupointsneed = cpupointsneed + 1
            cpuabsolute.append (x)
        while attack: ##This is where the playe and cpu take turns fighting
            #####Variables that will be used and that needs to be refreshed everytime the
            #####Player and CPU has attacked
            playerattack = True
            cpuattack = True
            hit = False
            allowed = True
            ok = True
##            print playerpointsneed
##            print cpupointsneed
            while playerattack: ##Player's turn to attack
                ok = True
                ##Draws the background background where the instructions appear
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                ##Writing the instruction
                playerturn = turnfont.render ("Pick the x coordinate you wish to attack",True,(RED))
                ##Displaying the box that will surround the instruction
                pygame.draw.rect (screen,GREEN,(screenx - playerturn.get_width()/2,30,playerturn.get_width(),playerturn.get_height()),0)
                ## Displaying the instruction 
                screen.blit (playerturn, (screenx - playerturn.get_width()/2,30))
                ##Getting the attack coordinate for x 
                attackcor = inputbox.ask (screen,"Coordinate")
                if attackcor == "leave" or attackcor == "quit": ##If the input value is leave or quit go to mainscreen
                    mainscreen (image)
                attackx = int (attackcor) ##Converts to int to use in array
                ##Writing the instruction to tell the player to pick what y coordinate to attack
                playerturn = turnfont.render ("Pick the y coordinate you wish to attack",True,(RED))
                ##Draws the background background where the instructions appear
                pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                ##Displaying the box that will surround the instruction
                pygame.draw.rect (screen,GREEN,(screenx - playerturn.get_width()/2,30,playerturn.get_width(),playerturn.get_height()),0)
                ## Displaying the instruction 
                screen.blit (playerturn, (screenx - playerturn.get_width()/2,30))
                attackcor = inputbox.ask (screen,"Coordinate") ##Getting the y coordinate the player wants to attack
                if attackcor == "leave" or attackcor == "quit": ##If the input value is leave or quit go to mainscreen
                    mainscreen (image)
                attacky = int(attackcor) ##Converts to int to use in array
                attack = (attackx,attacky)
                if attackx > 16 or attackx < 1: ##If the x coordinate chose to attack is out of the grid range,
                    allowed = False             ##Tells the player the coordinate is unavailable and foce them to input a new value
                    corunavailable = turnfont.render ("This Coordinate Does Not Work",True,WHITE)
                    pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                    pygame.draw.rect (screen,GREEN,(screenx - corunavailable.get_width()/2,30,corunavailable.get_width(),corunavailable.get_height()),0)
                    screen.blit (corunavailable,(screenx - corunavailable.get_width ()/2,30))
                    pygame.display.update ()
                    time.sleep (2)
                    ok = False
                elif attacky > 16 or attacky < 1:##If the y coordinate chose to attack is out of the grid range,
                    allowed = False             ##Tells the player the coordinate is unavailable and foce them to input a new value
                    corunavailable = turnfont.render ("This Coordinate Does Not Work",True,WHITE)
                    pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                    pygame.draw.rect (screen,GREEN,(screenx - corunavailable.get_width()/2,30,corunavailable.get_width(),corunavailable.get_height()),0)
                    screen.blit (corunavailable,(screenx - corunavailable.get_width ()/2,30))
                    pygame.display.update ()
                    time.sleep (2)
                    ok = False
                elif attacky <= 16 and attacky >= 1 and attackx <=16 and attackx >= 1: ##If the coordinates chosen are within range then move on 
                    allowed = True
                if allowed == True:
                    for x in playerattackcor: ##Checking to see if the new attacking coordinates have been used already.
                        if x == attack:       ## If the position has been already attacked then force the player to pick new coordinates
                            ok = False
                            corattacked = turnfont.render ("You already attacked this coordinate",True,WHITE)
                            pygame.draw.rect (screen,PURPLE,(0,15,1200,60),0)
                            pygame.draw.rect (screen,GREEN,(screenx - corattacked.get_width()/2,30,corattacked.get_width(),corattacked.get_height()),0)
                            screen.blit (corattacked,(screenx - corattacked.get_width ()/2,30))
                            pygame.display.update ()
                            time.sleep (2)
                if ok == True: ##If everything is fine then attack
                    playerattackcor.append (attack)
                    for x in cpuboat:
                        #print x
                        if x == attack: ##If the attacking coordinate matches CPU boat position draw a red box to indicate a hit
                            hitcor.append (attack)
                            hit = True
                            playerpoints = playerpoints + 1 ##Player gets a point for a hit
                            pygame.draw.rect (screen,RED,((attackx*30) + 686,(attacky*30)+76,29,29),0)
                            pygame.display.update()
                        if hit == False: ##If it is a miss then draw a white box to indicate a miss
                            pygame.draw.rect (screen,WHITE,((attackx*30) + 686,(attacky*30)+76,29,29),0)
                            pygame.display.update()
                    playerattack = False ##After attacking the turn ends
            while cpuattack: ##CPU's turn to attack
                #####Variables that will be used and that needs to be refreshed everytime the
                #####Player and CPU has attacked
                redo = False
                attackplayer = True
                posarray = 0
                cpuabsoluteattack = check[cpuhit]
##                print cpuabsoluteattack
##                print check
##                print cpuhit
                posarray = 0
                if attackplayer == True: ##If there is no overlap then store attacking value into an array
                    cpuhit = cpuhit + 1
                    for x in check: ##Checks everycoordinate attacked
##                        print x
##                        print cpucor
                        if x == cpuabsoluteattack: ##If the cpu attacked coordinates match the player coordinates draw a black box to indicate a hit
                            for i in cpuabsoluteattack:
                                if posarray == 0:
                                    cpuattackx = i
                                if posarray == 1:
                                    cpuattacky = i
                                posarray = posarray + 1
                            cpupoints = cpupoints + 1 ##Gets a point for hit
                            print cpupoints
                            pygame.draw.rect (screen,BLACK,(cpuattackx*30 - 24,cpuattacky*30 + 76,29,29))
                            pygame.display.update()
                    cpuattack = False ##End CPU Turn
            if playerpoints == playerpointsneed: ##If player gets the points needed to win, Player wins
                playerwin(image)
            if cpupoints == cpupointsneed:##If CPU gets the points needed to win, CPU wins
                cpuwin (image)
                pygame.display.update ()
            pygame.display.update
def playerwin (image): ##Player win
    screen.fill (BLACK)
    while True: 
        screen.blit (congrats,(0,0)) ##Draws the winner background
        returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE) ##shows how to leave the screen and go to main screen
        returnmainx = screenx*2 - returnmain.get_width()
        returnmainy = screen.get_height() - returnmain.get_height()
        screen.blit (returnmain, (returnmainx,returnmainy))
        winner = titlefont.render ("YOU WIN",True,WHITE) ##Displays that the player won
        winnerx = screenx - winner.get_width()/2
        screen.blit (winner,(winnerx,350 - winner.get_height()/2))
        for event in pygame.event.get():##Allows the player to quit to mainmenu 
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit() 
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    mainscreen(image)
        pygame.display.update()
def cpuwin (image): ##When CPU wins
    screen.fill (BLACK)
    while True: ##Draws the Loser's background 
        screen.blit (sinking,(0,0))
        returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE) ##Shows how to go to main screen
        returnmainx = screenx*2 - returnmain.get_width()
        returnmainy = screen.get_height() - returnmain.get_height()
        screen.blit (returnmain, (returnmainx,returnmainy))
        loser = titlefont.render ("YOU LOSE",True,WHITE) ##Shows the player that they lost
        loserx = screenx - loser.get_width()/2
        screen.blit (loser,(loserx,350 - loser.get_height()/2))
        for event in pygame.event.get():##Allows the player to quit to mainmenu 
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit() 
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    mainscreen(image)
        pygame.display.update()
def multiplayer(image):
    play = True
    while play:
        screen.blit (image,(0,0))
        returnmain = leavefont.render ("Press esc for mainscreen",True,WHITE)
        returnmainx = screenx*2 - returnmain.get_width()
        returnmainy = screen.get_height() - returnmain.get_height()
        screen.blit (returnmain, (returnmainx,returnmainy))
        for event in pygame.event.get():##Allows the player to quit to mainmenu 
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit() 
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    mainscreen(image)
        pygame.display.update()
        
while True:
    mainscreen(image)
