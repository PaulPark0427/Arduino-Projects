//Paul Park
//03-19-2018
//My Calculator
//Creates a simple calculator that can do simple arithmetic problems. 

package mycalculator;//Locating the program in the right package
	
//All of the imports needed to use FXML and scene builder. 
//Imports used to run the program
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;

public class Main extends Application {//Main class where my functions are ran
	@Override
	public void start(Stage primaryStage) {//opens the fxml 
		try {
			//This class sets up and displays the calculator
			BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("Calculator.fxml"));//Displays the calculator
			Scene scene = new Scene(root,600,600);//Size of the calculator
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {//Catches any errors
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);//Launch screen. Launches the code
	}
}
