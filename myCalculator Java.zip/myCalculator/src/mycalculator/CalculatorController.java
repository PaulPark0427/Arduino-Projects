//Paul Park
//03-19-2018
//My Calculator
//Creates a simple calculator that can do simple arithmetic problems. 

package mycalculator;//Package where the code is located

//Imports used to set up button and text field
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button; 
import javafx.scene.control.TextField; 

public class CalculatorController {//Main class for controller. This is where it determines what happens with the calculator
	@FXML
	private TextField displayField; //Sets up the id to reference for the text field
	String equation = null;//Variable used to store what equation is trying to be solved
	double first = 0; //First number inputted
	double second = 0; //Second number inputted
	double memory = 0; //Memory 
	double change = 0; //used to change the +- of the input
	boolean  firstinput = true; //helps determine which input is first or second
	int clearcount = 0; //checks how many times the screen was cleared
	double calculatedval = 0; //Where the answer is stored
	public void buttonClickHandler(ActionEvent evt) {//What happens when a button is pressed
		Button clickedButton = (Button) evt.getTarget();
		String buttonLabel = clickedButton.getText(); //The name on the button is recorded
		// Tell apart digits from operations
		switch(buttonLabel){
		//If the text on button is one of the cases, run this section of code
		case "0": case"1": case"2": case"3": case "4": case"5":
		case"6": case"7": case "8": case"9": case"10": case".":
			processDigit(buttonLabel);//runs the class that displays the inputted value
			clearcount = 0; 
			break;
		default://In any other scenario run this 
			System.out.println(equation);
			//if the button pressed is an equation run this code
			if ((firstinput == true) && (!buttonLabel.equals("C") && !buttonLabel.equals("MC") && !buttonLabel.equals("MR") && !buttonLabel.equals("+-") && !buttonLabel.equals("M+") && !buttonLabel.equals("M-"))) {
				first = Double.parseDouble(displayField.getText());//gets what the user inputted onto the text field
				System.out.println("You selected operation " + first);
				equation = buttonLabel; //remembers what equation was selected
				displayField.setText("");//Clears the display field
				firstinput = false; //Tells the code that first input is done
			}
			else if (buttonLabel.equals("=")){//When the equal button is pressed it will be sent to a class to be calculated based on what equation was selected
				//Resets it so that first input can be obtained
				second = Double.parseDouble(displayField.getText());//Gets user input
				OperationSecond(first,second,equation);//Class where its calculated
				firstinput = true; 
			}
			else if (buttonLabel.equals("C")) {//When C is pressed
				displayField.setText("");//Clear the text field
				clearcount++; //Increases the times clear ran
				if (clearcount == 2) {//If clear equals 2 times it will reset the text field and allows first input to be given
					displayField.setText("");
					firstinput = true; 
					clearcount = 0; //Allows the clear to be button to be used again 
				}
			}
			else if (buttonLabel.equals("MC")) {//When MC is pressed clear the memory 
				memory = 0; 
			}
			if (buttonLabel.equals("MR")) {//When MR is pressed shows the value stored in memory
				displayField.setText(Double.toString(memory));
			}
			if (buttonLabel.equals("M+")) {//Adds the current value displayed to the memory value
				memory = memory + Double.parseDouble(displayField.getText()); 
				displayField.setText("");//Clears the text field
			}
			if (buttonLabel.equals("M-")) {//Subtracts the displayed value from the memory 
				memory = memory - Double.parseDouble(displayField.getText());
				displayField.setText("");//Clears text field
			}
			if (buttonLabel.equals("+-")) {//When +- is presed, changes the +- of the displayed text
				change = Double.parseDouble(displayField.getText()); 
				change = change*(-1); 
				displayField.setText(Double.toString(change));
			}
		}
		}
	private void processDigit(String buttonLabel) {//used to add numbers to the text field
		displayField.setText(displayField.getText() + buttonLabel);
	}

	private void OperationSecond(double first, double second, String equation) {//used to calculate the equations
		System.out.println(first + " " + second);
		System.out.println(equation);
		if (equation.equals("+")) {//When + is the equation chosen, add the two inputs together
			adding(first,second,calculatedval); //class used to add value
		}
		else if (equation.equals("-")) {//When "-" is chosen, subtract the two inputs
			subtracting(first,second,calculatedval); //Class used to subtract values
		}
		else if (equation.equals("X")) {//When "X" is chosen multiply the two inputs
			multiplying(first,second,calculatedval);//Class used to multiply values
		}
		else if (equation.equals("/")) {//When "/" is chosen, divide the first input by second 
			dividing(first,second,calculatedval);//Function used to divide the inputs
		}
	}
	
	private void adding (double first, double second, double calculatedval) {//Adding function
		calculatedval = first + second;//Adds the two inputs
		displayField.setText(Double.toString(calculatedval)); //Displays the solution
	}
	
	private void subtracting (double first, double second, double calculatedval) {//Subtracting function 
		calculatedval = first - second; //Subtract first by second input
		displayField.setText(Double.toString(calculatedval)); //Displays the solution
	}
	
	private void multiplying (double first, double second, double calculatedval) {//Multiplying function
		calculatedval = first*second; //Multiply the two inputs
		displayField.setText(Double.toString(calculatedval));//Displaying the answer 
	}
	
	private void dividing (double first, double second, double calculatedval) {//Used to divide the inputs
		calculatedval = first/second; //Divide the first input by the second input
		displayField.setText(Double.toString(calculatedval)); //Displays the solution
	}
	
}
