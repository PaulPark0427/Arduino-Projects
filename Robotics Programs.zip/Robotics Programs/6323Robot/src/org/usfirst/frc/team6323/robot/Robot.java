/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package org.usfirst.frc.team6323.robot;

import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.ADXRS450_Gyro;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Preferences;
import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the build.properties file in the
 * project.
 */
public class Robot extends IterativeRobot {
	//game data
	String gameData;
	//preferences on dashboard
	//Preferences prefs;
	int target = 90;
	double gyroAngle;
	double error;
	double speed;
	double K = 0.02;
	private WPI_TalonSRX FLMotor, RLSlaveMotor, FRMotor, RRSlaveMotor;
	private Joystick joystickOne, joystickTwo;
	private Spark intakeMotor, intakeMotorTwo, climbMotor;
	private DifferentialDrive myRobot;
	
	private static final String kDefaultAuto = "Default";	
	private static final String customAuto = "Custom Auto";

	private ADXRS450_Gyro gyro;

	
	
	private String m_autoSelected;
	private SendableChooser<String> m_chooser = new SendableChooser<>();

	/**
	 * This function is run when the robot is first started up and should be
	 * used for any initialization code.
	 */
	@Override
	public void robotInit() {
		//gyro
		gyro = new ADXRS450_Gyro();
		gyro.reset();
		//drive motors
		joystickOne = new Joystick(0);
		//set talons
		FLMotor = new WPI_TalonSRX(1);
		FRMotor = new WPI_TalonSRX(3);
		//set slaves
		RLSlaveMotor = new WPI_TalonSRX(2);
		RRSlaveMotor = new WPI_TalonSRX(5);

		//Set follow motors
		RLSlaveMotor.follow(FLMotor);
		RRSlaveMotor.follow(FRMotor);

		myRobot = new DifferentialDrive(FLMotor, FRMotor);

		//subsystem motors
		intakeMotor = new Spark(0);
   	    intakeMotorTwo = new Spark(1);
		climbMotor = new Spark(9);
				
		m_chooser.addDefault("Default Auto", kDefaultAuto);
		m_chooser.addObject("Custom", customAuto);
		
		SmartDashboard.putData("Auto choices", m_chooser);
	}

	/**
	 * This autonomous (along with the chooser code above) shows how to select
	 * between different autonomous modes using the dashboard. The sendable
	 * chooser code works with the Java SmartDashboard. If you prefer the
	 * LabVIEW Dashboard, remove all of the chooser code and uncomment the
	 * getString line to get the auto name from the text box below the Gyro
	 *
	 * <p>You can add additional auto modes by adding additional comparisons to
	 * the switch structure below with additional strings. If using the
	 * SendableChooser make sure to add them to the chooser code above as well.
	 */
	@Override
	public void autonomousInit() {
		m_autoSelected = m_chooser.getSelected();
		// autoSelected = SmartDashboard.getString("Auto Selector",
		// defaultAuto);
		System.out.println("Auto selected: " + m_autoSelected);
		gameData = DriverStation.getInstance().getGameSpecificMessage();
	}

	public void leftCenter(){
	//myRobot.tankDrive(0.5, 0);
	
	}
	
	
	public void rightCenter() {
		
	}
	
	
	public void straight(){
		
	}
	/**
	 * This function is called periodically during autonomous.
	 */
	@Override
	public void autonomousPeriodic() {
		switch (m_autoSelected) {
			case customAuto: //Auto based on FMS
				
				
				break;
			default:
				// Put default auto code here
				break;
		}
	}
	
	/**
	 * This function is called periodically during operator control.
	 */
	@Override
	public void teleopPeriodic() {
		gyroAngle = gyro.getAngle();

		SmartDashboard.putNumber("Angle", gyroAngle);
		SmartDashboard.putNumber("FRMotor", FRMotor.get());
		SmartDashboard.putNumber("FLMotor", FLMotor.get());
		SmartDashboard.putNumber("RRMotor Voltage", RRSlaveMotor.getBusVoltage());
		SmartDashboard.putNumber("RLMotor Voltage", RLSlaveMotor.getBusVoltage());
		
		if(joystickOne.getRawButton(5)){
			
			target = 90;
			error = (target - gyroAngle);
				
			speed = (K * error);
			if (speed > 0.3){
				speed = 0.3;
			}
			if (speed < -0.3){
				speed = - 0.3;
			}
			
			FLMotor.set(speed);
			FRMotor.set(speed);
		}
		else if (joystickOne.getRawButton(6)){
			
			target = -90;
			error = (target - gyroAngle);
				
			speed = (K * error);
			if (speed > 0.3){
				speed = 0.3;
			}
			if (speed < -0.3){
				speed = - 0.3;
			}
			
			FLMotor.set(speed);
			FRMotor.set(speed);
		}
		else if(joystickOne.getRawButton(4)) {
				gyro.reset();
		}
		else{
			FLMotor.set(0);
			FRMotor.set(0);
		}
		
	}

	/**
	 * This function is called periodically during test mode.
	 */
	@Override
	public void testPeriodic() {
		
	}
}
